//   Header for storing cmake variables
//
//   author: Tomas Gonzalo
//////////////////////////////////////////////////

#pragma once

/* #undef USE_ROOT */
