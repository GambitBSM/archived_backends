# MINOS_chi2calc

This is a modified version of the chi^2 code released by the MINOS+ collaboration as supplementary material to https://arxiv.org/abs/1710.06488.

The original code can be found here: https://arxiv.org/src/1710.06488v6/anc

The code has been modified such that it can easily be connected to GAMBIT as a dynamically loaded backend. The important changes are:
- Added a C-style interface function `gambit_get_MINOS_chi2` for GAMBIT to call
- Switched off screen and file output by default
- Fixed a bunch of memory leaks 

The MINOS code must be built against **ROOT** and expects the input file `dataRelease.root`.

To build this code as a shared library, do:

```terminal
source /path/to/your/ROOT/bin/thisroot.sh
make
```

To adjust the default build settings just edit the Makefile or set the variables from the command line, e.g. 
```terminal
make CXX=g++-12 CXXFLAGS="-shared -fPIC -O2"
```

