# HepLikeData
Measurements used in the HepLike project.

This repository contains only the measurements that are used with the HEPLike package. To obtain the HEPLike package to go to:
https://github.com/mchrzasz/HEPLike

After cloning the repository link it as data in the HEPLike project

If you coded a new measurement and you want it to be included in this repository contact:
Marcin Chrzaszcz
mchrzasz ATNOSPAM cern.ch
Jihyun Bhom
jihyun.bhom ATNOSPAM cern.ch
