!*         -*- mode: fortran -*-
!************************************************************************
!***                           nucommon.h                             ***
!----------------------------------------------------------------------c
!  author: Pat Scott (p.scott@imperial.ac.uk), Jan 3, 2015

      character (len=17) version
      parameter(version = '1.0.9            ') ! Pad it with spaces at the end if < 17 characters


