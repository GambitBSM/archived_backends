Using :code:`DarkAges` with :code:`CLASS`
=========================================

