from .. import ska1_IM_band1
class ska1_IM_band2(ska1_IM_band1.ska1_IM_band1):
    pass