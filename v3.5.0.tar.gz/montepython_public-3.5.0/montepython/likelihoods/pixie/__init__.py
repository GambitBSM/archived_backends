# This likelihood falls under the mock SD likelihood type.
# The class below inherits the properties of a general class
# "Likelihood_sd", which knows how to deal with all types of
# spectral distortions experiments.

from montepython.likelihood_class import Likelihood_sd

class pixie(Likelihood_sd):
    pass
