# likelihood for P(k) from SDSS LRG (DR7)
from montepython.likelihood_class import Likelihood_mpk


class sdss_lrgDR7(Likelihood_mpk):
    pass
