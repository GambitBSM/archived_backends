from montepython.likelihood_class import Likelihood_clik


class lowlike(Likelihood_clik):
    pass
