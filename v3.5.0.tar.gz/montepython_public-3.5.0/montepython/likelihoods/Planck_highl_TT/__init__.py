from montepython.likelihood_class import Likelihood_clik


class Planck_highl_TT(Likelihood_clik):
    pass
