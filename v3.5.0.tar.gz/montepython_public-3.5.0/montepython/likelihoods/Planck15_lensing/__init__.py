from montepython.likelihood_class import Likelihood_clik


class Planck15_lensing(Likelihood_clik):
    pass
