from montepython.likelihood_class import Likelihood_clik


class Planck15_lowl_TT(Likelihood_clik):
    pass
