from montepython.likelihood_class import Likelihood_clik


class Planck15_highl_TTTEEE_lite(Likelihood_clik):
    pass
