from montepython.likelihood_class import Likelihood_clik


class Planck_highl_TT_lite(Likelihood_clik):
    pass
