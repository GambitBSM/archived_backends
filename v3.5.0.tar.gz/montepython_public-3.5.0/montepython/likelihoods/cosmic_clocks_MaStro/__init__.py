from montepython.likelihood_class import Likelihood_clocks


class cosmic_clocks_MaStro(Likelihood_clocks):
    pass
