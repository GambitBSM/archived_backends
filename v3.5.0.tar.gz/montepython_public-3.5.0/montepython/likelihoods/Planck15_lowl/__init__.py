from montepython.likelihood_class import Likelihood_clik


class Planck15_lowl(Likelihood_clik):
    pass
