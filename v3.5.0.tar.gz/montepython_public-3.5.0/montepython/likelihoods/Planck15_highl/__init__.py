from montepython.likelihood_class import Likelihood_clik


class Planck15_highl(Likelihood_clik):
    pass
