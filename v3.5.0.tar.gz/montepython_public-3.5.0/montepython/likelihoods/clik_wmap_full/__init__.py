from montepython.likelihood_class import Likelihood_clik


class clik_wmap_full(Likelihood_clik):
    pass
