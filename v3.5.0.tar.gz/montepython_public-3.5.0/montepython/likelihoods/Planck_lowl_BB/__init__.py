from montepython.likelihood_class import Likelihood_clik


class Planck_lowl_BB(Likelihood_clik):
    pass
