from montepython.likelihood_class import Likelihood_clik


class Planck_lensing(Likelihood_clik):
    pass
