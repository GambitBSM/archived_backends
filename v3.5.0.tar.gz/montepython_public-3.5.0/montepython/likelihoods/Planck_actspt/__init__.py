from montepython.likelihood_class import Likelihood_clik


class Planck_actspt(Likelihood_clik):
    pass
