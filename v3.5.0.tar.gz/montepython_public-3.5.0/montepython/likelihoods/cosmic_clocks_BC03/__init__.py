from montepython.likelihood_class import Likelihood_clocks


class cosmic_clocks_BC03(Likelihood_clocks):
    pass
