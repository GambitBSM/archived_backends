PolyChord module
================

.. automodule:: polychord
    :members:
    :undoc-members:
    :show-inheritance:

