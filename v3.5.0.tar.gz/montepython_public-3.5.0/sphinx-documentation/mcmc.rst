Mcmc module
===========

.. automodule:: mcmc
    :members:
    :undoc-members:
    :show-inheritance:
