Initialise Module
=================

.. automodule:: initialise
    :members:
    :undoc-members:
    :show-inheritance:
