MultiNest module
================

.. automodule:: multinest
    :members:
    :undoc-members:
    :show-inheritance:
