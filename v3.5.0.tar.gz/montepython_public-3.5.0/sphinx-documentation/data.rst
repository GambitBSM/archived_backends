Data module
===========

.. automodule:: data

.. autoclass:: Data
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource

.. autoclass:: Parameter
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
