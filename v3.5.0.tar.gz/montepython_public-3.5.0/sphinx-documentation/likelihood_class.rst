Likelihood class module
=======================

.. automodule:: likelihood_class
    :members:
    :undoc-members:
    :show-inheritance:
