make gencaplib.so
cp -r ak_files $DARKMESADIR
cp gencaplib.so $DARKMESADIR
