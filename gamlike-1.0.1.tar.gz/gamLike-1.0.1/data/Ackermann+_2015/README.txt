These limits come from arXiv:1503.02641, Ackermann+ 2015
https://www-glast.stanford.edu/pub_data/1048/
