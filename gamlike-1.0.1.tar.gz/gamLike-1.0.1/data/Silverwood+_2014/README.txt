Results taken from arXiv:1408.4131 (Silverwood+ 2014)
