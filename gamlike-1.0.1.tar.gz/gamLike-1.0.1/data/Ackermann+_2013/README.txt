These limits come from arXiv:1310.0828, Ackermann+ 2013
http://www-glast.stanford.edu/pub_data/713/
