From Calore+ 2014, arXiv:1409.0042
