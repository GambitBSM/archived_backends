/*
 * MinuitOnPathNormalInertialPotential.cpp
 *
 *  Created on: Nov 10, 2014
 *      Author: bol
 */

#include "BounceActionEvaluation/BounceActionPathFinding/MinuitOnPathNormalInertialPotential.hpp"

namespace VevaciousPlusPlus
{

  MinuitOnPathNormalInertialPotential::MinuitOnPathNormalInertialPotential()
  {
    // TODO Auto-generated constructor stub

  }

  MinuitOnPathNormalInertialPotential::~MinuitOnPathNormalInertialPotential()
  {
    // TODO Auto-generated destructor stub
  }

} /* namespace VevaciousPlusPlus */
