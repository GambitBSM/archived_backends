/*
 * WarningLogger.cpp
 *
 *  Created on: Dec 17, 2015
 *      Author: Ben O'Leary (benjamin.oleary@gmail.com)
 */


#include "Utilities/WarningLogger.hpp"

namespace VevaciousPlusPlus
{
  std::vector< std::string >* WarningLogger::warningMessages( NULL );
}

