===============
Release history
===============

* 10.11.2021: Release of `version 1.0.0 <https://github.com/temken/obscura/releases/tag/v1.0.0>`_
* 23.02.2021: Release of `version 0.1.0 <https://github.com/temken/obscura/releases/tag/v0.1.0>`_