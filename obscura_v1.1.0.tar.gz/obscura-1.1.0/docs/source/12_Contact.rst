=================
Contact & Support
=================

The author of *obscura* is `Timon Emken <https://timonemken.com/>`_.

For questions, support, bug reports, or other suggestions, please contact timon.emken@fysik.su.se or open an issue on `github <https://github.com/temken/obscura/issues>`_.