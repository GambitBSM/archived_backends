print(  " **************************************\n"\
        " *            pbarlike 1.0            *\n"\
        " *          arxiv: 23xx.xxxx          *\n"\
        " **************************************\n"\
        )
"""
.. todo::

    Add license and paper
"""