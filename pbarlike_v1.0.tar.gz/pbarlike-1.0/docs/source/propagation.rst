propagation module
------------------

Module containing class to configure the CR propagation model. 

.. _propagation:

.. automodule:: pbarlike.propagation
   :members:
   :undoc-members:
   :exclude-members: load_pp_data, load_pxs_cov_mat
   :show-inheritance: