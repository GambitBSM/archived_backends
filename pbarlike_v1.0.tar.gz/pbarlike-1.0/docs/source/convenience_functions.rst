convenience\_functions module
-----------------------------

Convenience functions to simulate antiproton fluxes using DRN and calculate likelihoods.

.. automodule:: pbarlike.convenience_functions
   :members:
   :undoc-members:
   :show-inheritance: