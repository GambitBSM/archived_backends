likelihoods module
------------------

Module with classes to define log likelihoods and log-likelihood ratios for given datasets and errors.

.. automodule:: pbarlike.likelihoods
   :members:
   :undoc-members:
   :show-inheritance: