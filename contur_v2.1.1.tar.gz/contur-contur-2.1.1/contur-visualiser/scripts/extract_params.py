import os
import sys


for subdir, dirs, files in os.walk(sys.argv[1]):
    for dir in dirs:
        ext = subdir + os.sep + dir
        os.system('bash extract_params.sh ' + ext)