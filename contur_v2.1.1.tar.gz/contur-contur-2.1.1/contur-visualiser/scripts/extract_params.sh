cd /contur/bin/

touch $1/processes.txt

./contur-extract-herwig-xs-br --ws -i $1 > $1/processes.txt

sed -i '/^$/d' $1/processes.txt
