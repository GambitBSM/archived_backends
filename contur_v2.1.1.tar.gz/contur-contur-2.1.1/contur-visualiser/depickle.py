import pickle
import os
import sys

dbfile = open(sys.argv[1], 'rb')
db = pickle.load(dbfile)
db.frame.to_csv("data/excl.csv")
# excl_file = open('data/excl.txt', 'w+')
# excl_file.write(str(db.conturDepotInbox))
# excl_file.close()
dbfile.close()
