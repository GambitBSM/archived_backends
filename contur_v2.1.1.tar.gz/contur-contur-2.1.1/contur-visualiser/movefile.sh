rm -r templates/point static/point
cd $1
cp -r $1/contur-plots/ $2/templates/point/
cp -r $1/contur-plots/ $2/static/point/
