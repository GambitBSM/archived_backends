# Additional or Modified Rivet info

Staging area for new or modified rivet routines (and REF data, metadata) before they have moved into
a rivet release.

## Theory

Library of SM Theory proedictions in yoda format (/THY/).
