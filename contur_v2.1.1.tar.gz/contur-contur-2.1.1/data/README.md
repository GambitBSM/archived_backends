# Data files

## DB
SQLite database files

## Models
UFO physics models, example generator steering files, additional limit files

## Plotting
Some possibly usefile plotting macros

## Rivet
Rivet routines not yet in the release. You can drop your own new or
modified in here and they will be use din preference to the released ones.

## Theory
SM Theory reference yoda files

## TheoryRaw
Archive of raw inputs used to build the files in the Theory directory.




