"""
The yoda_factories module contains three main components in the middle of the data flow, sitting between the high level steering
in :class:`contur.factories.Depot` class and the lower level statistics in the :class:`contur.factories.Likelihood` class
"""

import os
import re
import sys

import contur
import rivet
import yoda
import numpy
import traceback

def load_bg_data(path):
    """ 
    load the background (REF and THY data) for all the histograms associated with this rivet analysis
    """
    analysis, tag = contur.data.static_db.splitPath(path)

    analysis = rivet.stripOptions(analysis)
    
    if analysis in contur.config.found_ref:
        return
    
    if contur.config.onlyAnalyses and not (analysis in contur.config.onlyAnalyses):
        return

    if contur.config.vetoAnalyses and (analysis in contur.config.vetoAnalyses):
        return
        
    # first the measurement data
    
    a_name = analysis+".yoda"
    f = rivet.findAnalysisRefFile(a_name)
    contur.config.contur_log.debug("reading REF data for {} from {}".format(analysis, f))
    if len(f)==0:
        a_name = a_name+".gz"
        f = rivet.findAnalysisRefFile(a_name)
        if len(f)==0:
            contur.config.contur_log.error("Cannot find REF data for {}".format(analysis))
            contur.config.found_ref[analysis] = False
            return

    load_aos_from_file(f)
    contur.config.found_ref[analysis] = True

    # now see if there is any SM theory for this.
    a_name = analysis+"-Theory.yoda"
    f = rivet.findAnalysisRefFile(a_name)
    contur.config.contur_log.debug("reading REF data for {} from {}".format(analysis, f))
    if len(f)==0:
        a_name = a_name+".gz"
        f = rivet.findAnalysisRefFile(a_name)
        if len(f)==0:
            contur.config.contur_log.debug("Cannot find SM theory for {}".format(analysis))
            return

    load_aos_from_file(f)
    
    
def load_aos_from_file(f):
    """ 
    Load the relevant analysis objects (REF or THY) from the file f. 

    TODO. the list is actually analysis names, so we shouldn't even call
    this if they are in that.

    """
                
    aos = yoda.read(f) 
    for path, ao in aos.items():

        if not rivet.isRefPath(path) and not rivet.isTheoryPath(path):
            continue

        load_ao(path, ao)


def load_ao(path, ao):
    """
    Load the ao, with the path=path, into memory, as THY or REF histogram
    """
    # Convert all types to Scatter2D, including Scatter1Ds
    if ao.type() == "Scatter1D":
        ao = contur.util.mkScatter2D(ao)
    elif ao.type() == "Scatter3D":
        contur.config.contur_log.debug("Skipping 3D scatter dataset {}".format(ao.path()))
        return
    elif ao.type() != "Scatter2D":
        ao = yoda.mkScatter(ao)

    # Find out whether the cross-section has been scaled by some factor (e.g. to area-normalise it)
    # and whether it is a differential in number of events (usually searches), and if so in how many GeV.
    # The latter is only needed if it is an N_events plot with zero uncertainty (again, usually searches),
    # so we can calculate and use the Poisson error from the event number.
    try:
        _isScaled, _scaleFactorData, _nev_differential = contur.data.isNorm(ao.path())
    except contur.data.static_db.InvalidPath:
        return
                    
    # Build the covariance object to fill the dictionaries
    c = contur.data.CovarianceBuilder(ao)

    if rivet.isRefPath(path):

        if not _nev_differential==0:
            # root(n) errors on event count histos
            root_n_errors(ao,True,nx=_nev_differential,replace=True)
            
        if _isScaled:

            # if we are not running in grid mode, save the original for display purposes only.
            if not contur.config.silenceWriter:
                contur.config.plotObj[path] = ao.clone()
            scale_scatter_2d(ao, _scaleFactorData)

        contur.config.refObj[path] = ao
        # always fill the unCorr case in case we need it later
        contur.config.refUncorr[path] = c.buildCovFromErrorBar(
            assume_correlated=False)
        if c.hasBreakdown and contur.config.buildCorr:
            contur.config.refCorr[path] = c.buildCovFromBreakdown(
                ignore_corrs=False)
            contur.config.refErrors[path] = c.getErrorBreakdown()
            # print("{} REF errors {}".format(path,contur.config.refErrors[path]))
                
            # NB don't need to scale the errors again because they were already scaled in the "scale_scatter" step.

    if rivet.isTheoryPath(path):
        if _isScaled:
            if not contur.config.silenceWriter:
                contur.config.plotThObj[path] = ao.clone()
            scale_scatter_2d(ao, _scaleFactorData)
        contur.config.thyObj[path] = ao

        if c.hasBreakdown and contur.config.buildCorr:
            if contur.config.useTheoryCorr:
                contur.config.theoryCorr[path] = c.buildCovFromBreakdown(
                    ignore_corrs=False)
            # always fill the unCorr case in case we need it later
            contur.config.theoryUncorr[path] = c.buildCovFromBreakdown(
                ignore_corrs=True)

        else:
            if contur.config.useTheoryCorr:
                contur.config.theoryCorr[path] = c.buildCovFromErrorBar(
                    assume_correlated=True)
            contur.config.theoryUncorr[path] = c.buildCovFromErrorBar(
                assume_correlated=False)

        # NB don't need to scale the errors again because they were already scaled in the "scale_scatter" step.
        contur.config.theoryErrors[path] = c.getErrorBreakdown()

        if contur.config.min_np:
            # this option is slow, so look for and store pre-existing tests on the background-only
            contur.config.theoryTS[path] = contur.util.get_theory_ts(path)
            if contur.config.theoryTS[path] is None:
                contur.config.contur_log.warning("No test statistic file found for {}".format(path))


def scale_scatter_2d(ao, sf):
    """
    Apply the scales factor sf to the yoda analysis object ao.
    """
    
    for i in range(0, len(ao.points())):
        ao.points()[i].setY(ao.points()[i].y() * sf)
        contur.config.contur_log.debug(
                "Scaling {}: {} SF={}".format(ao.path(),ao.points()[i].yErrs(), sf))
        if ao.hasValidErrorBreakdown():
            for source in ao.variations():
                ao.points()[i].setErrMinus(2,ao.points()[i].errMap()[source][0]*sf, source)
                ao.points()[i].setErrPlus(2,ao.points()[i].errMap()[source][1]*sf, source)
        else:
            ao.points()[i].setYErrs(
                map(lambda x: x * sf, ao.points()[i].yErrs()))
        contur.config.contur_log.debug("Scaled: {}".format(ao.points()[i].yErrs()))


def root_n_errors(ao, is_evcount, nx=0.0, lumi=1.0, replace=False):
    """Function to include root(number of expected events) errors in the uncertainties of 2D scatter.

    The uncertainty based on the expected events for the relevant integrated luminosity. This is
    not about MC statistics!

    The minimum uncertainty is one event... we are not doing proper low-stat treatment in tails,
    so this is a conservative fudge.

    :arg ao:
           The ``YODA`` analysis object to be manipulated.
    :type: :class:`YODA.AnalysisObject`

    :arg nx: factor needed to convert to number of events for none-uniform bin widths (<0, not used, ==0, do nothing).
    :type: float

    :arg is_evcount:
           True is the plot is in event numbers. Otherwise assumed to be a differential cross section.
    :type: boolean

    :arg lumi:
           Integrated luminiosity used to get event counts from differential cross sections
    :type: float

    :arg replace:
           If True replace the uncertainties. In False (default) add them in quadrature.
    :type: bool

    """

    try:
        for point in ao.points():

            yup, ydown = point.yErrs()
            if replace and not (yup==0 and ydown==0):
                contur.config.contur_log.warning("Overwriting non-zero uncertainty for {}.".format(ao.path()))

            if is_evcount:
                if nx < 0:
                    # all we need is the square root
                    uncertainty = max(numpy.sqrt(point.y()),1.0)
                else:
                    # plot was presented as a differential number of events with non-constant bin width, need to multiply
                    # by bin width and divide the differential factor.
                    bw = point.xErrs()[0]*2.0
                    if nx > 0:
                        num_events = max(point.y()*bw/nx,1.0)
                        uncertainty = max(nx*numpy.sqrt(num_events)/bw,1.0)
                    else:
                        contur.config.contur_log.warning("nx=0 for event count histo {}. Should not happen.".format(ao.path()))

            else:
                # cross section plots.
                bw = point.xErrs()[0]*2.0
                num_events = max(point.y()*bw*lumi,1.0)
                uncertainty = numpy.sqrt(num_events)/(bw*lumi)


            if replace:
                point.setYErrs(uncertainty,uncertainty)
            else:
                point.setYErrs(numpy.sqrt(uncertainty**2+yup**2),numpy.sqrt(uncertainty**2+ydown**2))

    except AttributeError as ate:
        contur.config.contur_log.error("No points for {}. {}".format(ao.path(),ate))

class HistFactory(object):
    """
        Processes and decorates :class:`YODA.AnalysisObject` to a testable format, filling a candidate block by default

        :param ana_obj: ``YODA`` AO to dress
        :type ana_obj: :class:`YODA.AnalysisObject`
        :param xsec:
            _XSEC scatter recording generator cross section in YODA file (*contained in all Rivet run outputs*)
        :type xsec: :class:`YODA.Scatter1D`
        :param nev:
            _EVTCOUNT scatter recording total generated events in YODA file (*contained in all Rivet run outputs*)
        :type nev: :class:`YODA.Scatter1D`


    """

    def __init__(self, ana_obj, xsec, nev):

        # Construct with an input YODA AO list, and a Scatter1D for the cross section and nEv
        self.signal = ana_obj
        self.xsec = xsec
        self.nev = nev

        # Measurement and theory (always have this meaning, whatever is used as background)
        self._ref = None
        self._thy = None
        self.pool = None

        self._weight = rivet.extractWeightName(self.signal.path())
        if self._weight != contur.config.weight:
            return

        self.signal.setPath(rivet.stripWeightName(self.signal.path()))

        # Initialize the public members we always want to access
        self._CLs = None
        self._IDstring = ''
        self._has1Dhisto = None
        self._isRatio = contur.data.isRatio(ana_obj.path())
        self._isProfile = False
        self._isSearch = contur.data.isSearch(ana_obj.path())
        self._background = None
        self._stack = yoda.Scatter2D

        # these should just be used for plotting, which is not done if writer is silenced (e.g. in gridMode)
        if not contur.config.silenceWriter:
            self._refplot = None
            self._sigplot = None
            self._bgplot = None
            self._thyplot = None

        self._lumi = 1
        self._isScaled = False
        self._scaleFactorData = 1
        self._scaleFactorSig = 1
        self._conturPoints = []
        self._nev_differential = 1.0
        self._maxcl = -1
        self._maxbin = -1
        self._cov = None
        self._uncov = None
        self._nuisErrs = None
        self._likelihood = None

        self._gotTh = False
        self._thCov = None
        self._thUncov = None
        self._thErrs = None

        # Call the internal functions on initialization
        # to fill the above members with what we want, these should all be private


        # Get the measurement reference data.
        if not self.__getData():
            return

        # Get the theory reference data. (Do this even if not using it, as it is useful for reference.)
        self.__getThy()
        if (contur.config.theoryOnly or contur.config.expectedLimit) and not self._gotTh:
            # can't carry on with these options if there is no theory prediction available.
            # TODO: log an explanation / complaint?
            return

        self._useTheory=(self._theoryComp or contur.config.useTheory or contur.config.expectedLimit) and self._gotTh

        # If no background has been assigned, use the measurement as the background
        if self._ref is not None and self._background is None:
            self._background = self._ref.clone()

        if contur.config.expectedLimit:
            # copy the SM theory to use it as the measurement too.
            self.__theoryToRef()

        self.__getAux()
        if self.pool is None:
            return
        
        self.__getisScaled()


        # Determine the type of object we have, and build a 2D scatter from it if it is not one already
        # Also recalculate scalefactor, if appropriate
        if self.signal.type() in ['Histo1D', 'Profile1D', 'Counter']:
            self._has1Dhisto = True #< remove?

            self._isProfile = self.signal.type().startswith("Profile")

            if self._isScaled:
                # if the plot is area normalised (ie scaled), work out the factor from number of events and generator xs
                # (this is just the integrated cross section associated with the plot)
                # TODO: should maybe be using effNumEntries to correctly handle weighted events?
                try:
                    self._scaleFactorSig = \
                        float(self.xsec.point(0).x()) * float(self.signal.numEntries()) / float(self.nev.numEntries())


                except Exception as e:
                    contur.config.contur_log.warning(
                        "missing info for scalefactor calc", exc_info=e)

            # contur.config.contur_log.warning("XXX {} ({}): {:d} bins in hist vs {:d} in scatter".\
            #                                  format(self.signal.path(), self.signal.type(),
            #                                         len(self.signal), len(yoda.mkScatter(self.signal))))
            self.signal = yoda.mkScatter(self.signal)
            # Make sure it is actually a Scatter2D - mkScatter makes Scatter1D from counter.
            if self.signal.type() == 'Scatter1D':
                self.signal = contur.util.mkScatter2D(self.signal)


        # include the stat uncertainties on the expected number of events.
        root_n_errors(self.signal,self._isSearch,nx=self._nev_differential,lumi=self._lumi)

        if not contur.config.silenceWriter:
            # Public member function to build plots needed for direct histogram visualisation
            # avoid calling YODA.clone() unless we have to
            # Must be called before scaling.
            if self._ref:
                self.doPlot()
            else:
                contur.config.contur_log.warning("No reference data found for histo: {}".format(self.signal.path()))


        # if everything we need is available, there will be ref data.
        if self._ref and self.xsec:
            # don't scale histograms that came in as 2D scatters
            if self._has1Dhisto and self._isScaled:
                self.__doScale()
            self.__fillBucket()


    def __getisScaled(self):
        """Internal function to look up Scaling attributes from the contur database, defined in :mod:`contur.data`

        :Built members:
            * *isScaled* (``bool``) --
              True if some scaling has been applied to this histogram
            * *scaleFactorData* (``float``) --
              Factor to scale the ref data by (n count) to undo the normalisation

        """
        self._isScaled, self._scaleFactorData, self._nev_differential = contur.data.isNorm(self.signal.path())


    def __getData(self):
        """
        Internal function to look up the refdata

        :Built members:
            * *ref* (:class:YODA.Scatter2D) --
              Reference scatter plot matching path from input signal aos
            * *nuisErrs* (:class:`numpy.array`) --
              Uncertainty contributions on the reference data
            * *cov* (:class:`numpy.array`) --
              Built covariance matrix from ref annotations
            * *uncov* (:class:`numpy.array`) --
              Built covariance matrix from ref annotations assuming all uncertainty is fully uncorrelated

        """

        try:
            self._ref = contur.config.refObj["/REF" + rivet.stripOptions(self.signal.path())]
        except:
            return False

        try:
            self._cov = contur.config.refCorr["/REF" + rivet.stripOptions(self.signal.path())].copy()
            self._nuisErrs = contur.config.refErrors["/REF" + rivet.stripOptions(self.signal.path())].copy()
            contur.config.contur_log.debug(
                    "Attempting to use correlation information for %s" % self.signal.path())
        except:
            contur.config.contur_log.debug(
                    "No correlation information for %s" % self.signal.path())
            self._cov = None
            self._nuisErrs = None
        try:
            self._uncov = contur.config.refUncorr["/REF" + rivet.stripOptions(self.signal.path())].copy()
        except:
            self._uncov = None
            return False
        return True


    def __theoryToRef(self):
        """Internal function to replace the refdata (central values only) with the theory

        :Modified members:
            * *ref* (:class:YODA.Scatter2D) --
              Reference scatter plot matching path from input signal aos

        """

        # can't do this if we don't have a theory prediction!
        if not self._gotTh:
            return

        for i in range(0, len(self._ref.points())):
            self._ref.points()[i].setY(self._thy.points()[i].y())
            if not contur.config.silenceWriter:
                try:
                    contur.config.plotObj["/REF" + rivet.stripOptions(self.signal.path())].points()[i].setY(
                        contur.config.plotThObj["/THY" + rivet.stripOptions(self.signal.path())].points()[i].y())
                except KeyError:
                    # no problem, this just means the plot is unscaled.
                    continue


    def __getThy(self):
        """
        Internal function to look up the SM theory data

        :Built members:
            * *thy* (:class:YODA.Scatter2D) --
              SM Theory prediction matching path from input signal aos
            * *thCov* (:class:`numpy.array`) --
              Built covariance matrix from thy annotations
            * *thUncov* (:class:`numpy.array`) --
              Built covariance matrix from thy annotations assuming all uncertainty is fully uncorrelated
            * *thErrs* (:class:`numpy.array`) --
              Uncertainty contributions on the theory data
            * *background* (:class:YODA.Scatter2D) --
              Background model, either built from the ref or thy if found and want to use

        """

        # find whether theory is always required for this histogram
        self._theoryComp = contur.data.theoryComp(self.signal.path())

        try:
            self._thy = contur.config.thyObj["/THY" +
                                             rivet.stripOptions(self.signal.path())]
            self._gotTh = True

            if self._theoryComp or contur.config.useTheory or contur.config.expectedLimit:
                self._background = self._thy.clone()

                try:
                    self._thCov = contur.config.theoryCorr["/THY" + rivet.stripOptions(self.signal.path())].copy()
                    self._thErrs = contur.config.theoryErrors["/THY" + rivet.stripOptions(self.signal.path())].copy()
                except:
                    self._thCov = None
                    self._thErrs = None
                try:
                    self._thUncov = contur.config.theoryUncorr["/THY" + rivet.stripOptions(self.signal.path())].copy()
                except KeyError:
                    self._thUncov = None
                    # just warn if we can't build theory, it's less important...
                    contur.config.contur_log.warning(
                        "Could not build any theory error source for %s" % self.signal.path())
                
                contur.config.contur_log.debug(
                        "Using theory for {}".format(self._thy.path()))
        except KeyError:
            # No theory for this one
            self._gotTh = False


    def doPlot(self):
        """Public member function to build yoda plot members for interactive runs"""
        # see if there are unscaled versions of the histos
        try:
            self._refplot = contur.config.plotObj["/REF" +
                                                  rivet.stripOptions(self.signal.path())]
        # otherwise the standard ref should be unscaled
        except KeyError:
            self._refplot = self._ref.clone()

        # and the same thought process for the background model, and for the theory (even if the
        # theory is not being used as background).
        if self._useTheory:
            try:
                # this only exists for scaled plots.
                self._bgplot = contur.config.plotThObj["/THY"+rivet.stripOptions(self.signal.path())]
            except KeyError:
                self._bgplot = contur.config.thyObj["/THY"+rivet.stripOptions(self.signal.path())]
        else:
            self._bgplot = self._refplot.clone()

        if self._gotTh:
            try:
                self._thyplot = contur.config.plotThObj["/THY" + rivet.stripOptions(self.signal.path())]
            except KeyError:
                self._thyplot = contur.config.thyObj["/THY" + rivet.stripOptions(self.signal.path())]



        # build stack for plotting, for histogrammed data
        if not self._isRatio:
            self.__buildStack()
        else:
            self._stack = self.signal.clone()
        self._sigplot = self.signal.clone()


    def __getAux(self):
        """Internal function to look up auxiliary attributes from the contur database, defined in :mod:`contur.stat`

        :Built members:
            * *pool* (``string``) --
              String for analysis pool looked up from contur database
            * *subpool* (``string``) --
              String for analysis subpool looked up from contur database

        """
        self._lumi, self.pool, self.subpool = contur.data.LumiFinder(
            self.signal.path())


    def __buildStack(self):
        """Private function to stack the signal for easier visualisation

        """

        if self.signal.type() != "Scatter2D":
            return False
        elif not self._bgplot:
            return False
        else:
            self._stack = self.signal.clone()
            if self._stack.numPoints() != self._bgplot.numPoints():
                contur.config.contur_log.warning(
                    "%s : stack and background have unequal numbers of points. Skipping." % self._bgplot.path())
                return False

            for i in range(0, len(self._stack.points())):
                self._stack.points()[i].setY(
                    self._stack.points()[i].y() * self._scaleFactorSig / self._scaleFactorData +
                    self._bgplot.points()[i].y())

                if self._useTheory:
                    eu2 = (self.signal.points()[i].yErrs()[0]*self._scaleFactorSig/self._scaleFactorData)**2 + self._bgplot.points()[i].yErrs()[0]**2
                    ed2 = (self.signal.points()[i].yErrs()[1]*self._scaleFactorSig/self._scaleFactorData)**2 + self._bgplot.points()[i].yErrs()[1]**2
                    self._stack.points()[i].setYErrs(numpy.sqrt(eu2),numpy.sqrt(ed2))
                else:
                    # set these to include only the BSM errors, since that is what is used in the test
                    self._stack.points()[i].setYErrs(self.signal.points()[i].yErrs()[0] * self._scaleFactorSig / self._scaleFactorData,
                                                     self.signal.points()[i].yErrs()[1] * self._scaleFactorSig / self._scaleFactorData)


    def __doScale(self):
        """Private function to perform the normalisation of the signal
        """

        if self.signal.type() != "Scatter2D":
            return

        for i in range(0, len(self.signal.points())):
            self.signal.points()[i].setY(self.signal.points()[
                i].y() * self._scaleFactorSig)
            self.signal.points()[i].setYErrs(
                map(lambda x: x * self._scaleFactorSig, self.signal.points()[i].yErrs()))


    def __fillBucket(self):
        """Create a block, contains the observables from this histogram and their correlation plus statistical metrics

        :Built members:
            * *block* (:class:`contur.block`) --
              Automatically filled bucket containing statistical test pertaining to this histogram

        """
        if len(self._ref.points()) != len(self.signal.points()):
            contur.config.contur_log.critical(
                "Ref data and signal for {} have unequal numbers of points ({} vs {})".format(
                    self.signal.path(), len(self._ref.points()), len(self.signal.points())) )
            raise Exception

        # estimate the stat error on the expected signal.
        # TODO: signal errors are symmetrised here. Does that make any difference? (should not)
        yErrs = self.signal.yErrs()
        serrs = []
        for epair in yErrs:
            # these are the MC stat errors
            serrs.append((abs(epair[0]) + abs(epair[1]))*0.5)

        bin_widths = []
        try:
            for xerr in self._background.xErrs():
                bin_widths.append(xerr[0])
                
            self._likelihood = contur.factories.Likelihood(bw=bin_widths,
                                                           nobs=self._ref.yVals(),
                                                           cov=self._cov,
                                                           uncov=self._uncov,
                                                           bg=self._background.yVals(),
                                                           s=self.signal.yVals(),
                                                           serr=serrs,
                                                           theorycov=self._thCov, theoryuncov=self._thUncov,
                                                           nuisErrs=self._nuisErrs, thErrs=self._thErrs,
                                                           ratio=self._isRatio,
                                                           profile=self._isProfile,
                                                           #useTheory=(self._theoryComp or contur.config.useTheory),
                                                           useTheory=self._useTheory,
                                                           lumi=self._lumi,
                                                           sxsec=self.xsec.point(0).x(), #< and uncertainty?
                                                           bxsec=self._scaleFactorData, #< TODO: a hack for profiles etc. Improve?
                                                           tags=rivet.stripOptions(self.signal.path()))
        except AttributeError as ate:
            contur.config.contur_log.fatal("This can happen when your yodafile is corrupted: {}".format(ate))
            traceback.print_exc()
            sys.exit(1)

        self._likelihood.pools = self.pool
        self._likelihood.subpools = self.subpool

        # Lastly for convenience and user info get the bucket CLs and attach it to a member of histFactory
        self._CLs = self._likelihood.CLs


    @property
    def CLs(self):
        """CLs score derived from this histogram

        .. note:: this duplicates the method defined in ::attr::`likelihood`

        **type** (``float``)
        """
        return self._CLs
    @CLs.setter
    def CLs(self,val):
        self._CLs = val
    

    @property
    def background(self):
        """Background model, scaled if required

        **type** (:class:`YODA.Scatter2D`)
        """
        return self._background


    @property
    def ref(self):
        """
        Reference data, observed numbers input to test, scaled if required

        **type** (:class:`YODA.Scatter2D`)
        """
        return self._ref


    @property
    def thy(self):
        """
        Reference SM theory data, scaled if required

        **type** (:class:`YODA.Scatter2D`)
        """
        return self._thy


    @property
    def stack(self):
        """Stacked, unscaled Signal+background for plotting

        **type** (:class:`YODA.Scatter2D`)
        """
        return self._stack


    @property
    def sigplot(self):
        """Signal for plotting

        **type** (:class:`YODA.Scatter2D`)

        """
        return self._sigplot
    @sigplot.deleter
    def sigplot(self):
        del self._sigplot

    @property
    def refplot(self):
        """Reference data for plotting

        **type** (:class:`YODA.Scatter2D`)

        """
        return self._refplot


    @property
    def bgplot(self):
        """Background data for plotting

        **type** (:class:`YODA.Scatter2D`)

        """
        return self._bgplot


    @property
    def thyplot(self):
        """Theory for plotting

        **type** (:class:`YODA.Scatter2D`)

        """
        return self._thyplot


    @property
    def scaled(self):
        """Bool representing if there is additional scaling applied on top of luminosity

        **type** (``bool``)

        """
        return self._isScaled


    @property
    def has_theory(self):
        """Bool representing if a theory prediction was found for the input signal

        **type** (``bool``)

        """
        return self._gotTh


    @property
    def signal_scale(self):
        """Scale factor applied to the signal histogram/scatter, derived generally from input nEv and xs

        **type** (``float``)
        """
        return self._scaleFactorSig


    @property
    def data_scale(self):
        """Scale factor applied to the refdata histogram/scatter

        **type** (``float``)


        """
        return self._scaleFactorData


    @property
    def likelihood(self):
        """The instance of :class:`~contur.factories.likelihood.Likelihood` derived from this histogram

        **type** (:class:`~contur.factories.likelihood.Likelihood`)

        """
        return self._likelihood
    @likelihood.setter
    def likelihood(self,lh):
        self._likelihood = lh
        
    def __repr__(self):
        if not self.signal.path():
            tag = "Unidentified Source"
        else:
            tag = self.signal.path()
        return "%s from %s, with %s" % (self.__class__.__name__, tag, self._likelihood)


class YodaFactory(object):
    """Class controlling Conturs YODA file processing ability

    This class is initialised from an os path to a ``YODA`` analysis object file and
    dresses it by iterating through each ao and wrapping that in an instance of
    :class:`~contur.factories.yoda_factories_HistFactory` which extracts the required
    :class:`~contur.factories.likelihood.Likelihood` block from each aos. This class then contains
    the aggregated information for all of these instances across the entire ``YODA`` file.

    path to output plot objects is detemined by contur.config.plot_dir

    :param yodaFilePath: Valid :mod:`os.path` filesystem YODA file location
    :type yodaFilePath: ``string``

    :Keyword Arguments:
        * *noStack* (``bool``) -- Mark true to not stack the signal on background in plotting (*cosmetic*)

    """

    def __init__(self, yodaFilePath, noStack=False):
        self.yodaFilePath = yodaFilePath

        self._likelihood_blocks = []
        self._sorted_likelihood_blocks = []
        self._full_likelihood = contur.factories.CombinedLikelihood()

        self._NoStack = noStack

        self.__get_likelihood_blocks()


    def __get_likelihood_blocks(self):
        """
        Private function to collect all of the conturBuckets from a YODA file

        :Built variables:
        * **conturBuckets** (:class:`contur.block`) --
          List of all conturBuckets created from YODA file
        """

        mc_histos, x_sec, nev = contur.util.get_histos(self.yodaFilePath)
        if mc_histos is None or len(mc_histos)==0:
            return

        for path, ao in contur.util.progress_bar(mc_histos.items(), total=len(mc_histos)):

            if contur.data.validHisto(path):

                # now load the REF and SM THY info for this analysis, if not already there. 
                load_bg_data(path)

                histo = contur.factories.HistFactory(ao, x_sec, nev)

                # if we are running on theory only, require it exists.
                if histo._ref is not None and (histo.has_theory or not contur.config.theoryOnly):
                    
                    contur.config.contur_log.debug(
                        "Processed measurement {}".format(histo.signal.path()))

                    # write out the plot .dat files
                    if not contur.config.silenceWriter:
                        plotdirs = [os.path.abspath(
                            os.path.dirname(f)) for f in self.yodaFilePath]
                        plotparser = rivet.mkStdPlotParser(plotdirs, )
                        contur.util.write_histo_dat(self.yodaFilePath, plotparser, self._NoStack, histo)
                    if histo._likelihood:
                        # I don't like this but check that a CLs value was built or throw the bucket out
                        if histo._likelihood.CLs is not None:
                            self._likelihood_blocks.append(histo._likelihood)


        # we cannot pickle yoda objects so we just declare them in this scope when we are scrubbing the yodafile
        del mc_histos, x_sec, nev


    def sort_blocks(self, omitted_pools=""):
        """Function that sorts the list of likelihood blocks extracted from the ``YODA`` file

        This function implements the sorting algorithm to sort the list of all extracted :class:`~contur.factories.likelihood.Likelihood`
        blocks in the :attr:`likelihood_blocks` list, storing the reduced list in the :attr:`sorted_likelihood_blocks` list

        :Keyword Arguments:
            * *omittedPools* (``string``) --
              String of analysis pools to omit
        """
        pools = []
        [pools.append(x) for x in [
            item.pools for item in self._likelihood_blocks] if x not in pools]
        for p in pools:
            if omitted_pools == p:
                continue
            anas = []
            [anas.append(x) for x in
             [contur.config.ANALYSIS.search(item.tags).group() for item in self._likelihood_blocks if
              item.tags and item.pools == p] if
             x not in anas]
            for a in anas:
                subpools = []
                for item in self._likelihood_blocks:
                    if item.pools == p and a in item.tags:
                        if item.subpools not in subpools and item.subpools is not None:
                            subpools.append(item.subpools)

                if len(subpools) > 0:
                    result = {}
                    for sp in subpools:
                        result[sp] = contur.factories.CombinedLikelihood()

                    for k, v in result.items():
                        # Remove the point if it ends up in a group
                        # Tags need to store which histo contribute to this point.
                        for y in self._likelihood_blocks:
                            if y.subpools == k and a in y.tags:
                                result[k].add_likelihood(y)
                                if len(result[k].tags) > 0:
                                    result[k].tags += ","
                                result[k].tags += y.tags

                        v.calc_cls()
                        v.pools = p
                        v.tags = result[k].tags

                    # add the max subpool back into the list of points with the pool tag set but no subpool
                    [self._likelihood_blocks.append(v) for k, v in
                     result.items()]  # if v.CLs == max([z.CLs for z in result.values()])


       
        pool_list = []
        cls_list = []
        for x in self._likelihood_blocks:
            pool_list.append(x.pools)
            cls_list.append(x.CLs)
        
        # Create dictionary of empty lists
        combine_pool_cls_group = {}        
        for i in set(pool_list):
            combine_pool_cls_group[i] = []
        
        combine_pool_cls = list(zip(pool_list,cls_list))
        
        #Key is the pool pointing to list of CLs for pool
        for pair in combine_pool_cls:
            combine_pool_cls_group[pair[0]].append(pair[1])
        
        #Take the maximum CLS in each list
        for i in combine_pool_cls_group:
            combine_pool_cls_group[i] = max(combine_pool_cls_group[i])
        
        for p in pools:
            if not p == omitted_pools:
                for item in self._likelihood_blocks:
                    if item.CLs == combine_pool_cls_group[p] \
                            and item.pools == p \
                            and item.pools not in [x.pools for x in self._sorted_likelihood_blocks]:
                        self._sorted_likelihood_blocks.append(item)

        # once all the points are sorted and the representative of each pool is put into _sortedPoints, work out the
        # final exclusion
        self.build_full_likelihood(omitted_pools)


    def _resort_blocks(self):
        """Private function to sort the :attr:`sorted_likelihood_blocks` list *used for resorting after a merging exclusively*

        .. todo:: this is unceccesary code duplication and should be removed

        :Keyword Arguments:
            * *omittedPools* (``string``) --
              String of analysis pools to omit
        """
        pools = []
        [pools.append(x) for x in [
            item.pools for item in self.sorted_likelihood_blocks] if x not in pools]
        for p in pools:
            anas = []
            [anas.append(x) for x in
             [contur.config.ANALYSIS.search(item.tags).group() for item in self.sorted_likelihood_blocks if
              item.tags and item.pools == p]
             if
             x not in anas]
            for a in anas:
                subpools = []
                [subpools.append(x) for x in
                 [item.subpools for item in self.sorted_likelihood_blocks if item.pools == p and a in item.tags] if
                 x not in subpools]
                if subpools[0]:
                    result = {}
                    for sp in subpools:
                        result[sp] = contur.factories.CombinedLikelihood()
                    for k, v in result.items():
                        # Remove the point if it ends up in a group
                        # Tags need to store which histo contribute to this point.
                        for y in self.sorted_likelihood_blocks:
                            if y.subpools == k and a in y.tags:
                                result[k].add_likelihood(y)
                                # result[k].addPoint(y)
                                if len(result[k].tags) > 0:
                                    result[k].tags += ","
                                result[k].tags += y.tags
                        v.calc_cls()
                        v.pools = p
                        v.tags = result[k].tags
                    # add the max subpool back into the list of points with the pool tag set but no subpool
                    [self._sorted_likelihood_blocks.append(v) for k, v in
                     result.items()]  # if v.CLs == max([z.CLs for z in result.values()])

        tempStore = []

        for p in pools:
            [tempStore.append(item) for item in self.sorted_likelihood_blocks if item.CLs == max(
                [x.CLs for x in self.sorted_likelihood_blocks if x.pools == p]) and item.pools == p and item.pools not in [x.pools
                                                                                                                           for x in
                                                                                                                           tempStore]]
        self._sorted_likelihood_blocks = tempStore
        # once all the points are sorted and the representative of each pool is put into _sorted_likelihood_blocks, work out the
        # final exclusion
        self.build_full_likelihood()

        # cleanup some bulk we don't need
        if hasattr(self, '_likelihood_blocks'):
            del self._likelihood_blocks
        if hasattr(self, 'yodaFilePath'):
            del self.yodaFilePath
    
    def drop_na_likelihood_blocks(self):
        """Method to drop likelihood_blocks with nan for cls
        """

        self._likelihood_blocks = [like_ob for like_ob in self._likelihood_blocks
                                   if like_ob._CLs is not None]

    def build_full_likelihood(self, omittedPool=""):
        """Function to build the full likelihood representing this entire ``YODA`` file

        This function takes the :attr:`sorted_likelihood_blocks` and combines them as statistically uncorrelated
        diagonal contributions to a :class:`~contur.factories.likelihood.CombinedLikelihood` instance which is stored
        as an attribute to this class as :attr:`likelihood`

        :Keyword Arguments:
            * *omittedPools* (``string``) --
              String of analysis pools to omit
        """
        self._full_likelihood = contur.factories.CombinedLikelihood()
        for x in self._sorted_likelihood_blocks:
            if x.pools != omittedPool:
                self._full_likelihood.add_likelihood(x)
        self._full_likelihood.calc_cls()


    @property
    def sorted_likelihood_blocks(self):
        """The list of reduced component likelihood blocks extracted from the ``YODA`` file

        This attribute is derived from the :attr:`likelihood_blocks` attribute, and is the result of sorting
        this list (using :func:`sort_blocks`), resulting in the list of components entering into the calculated
        :attr:`full_likelihood`

        **type** ( ``list`` [ :class:`~contur.factories.likelihood.Likelihood` ])

        """
        return self._sorted_likelihood_blocks
    
    @sorted_likelihood_blocks.setter
    def sorted_likelihood_blocks(self, value):
        self._sorted_likelihood_blocks = value


    @property
    def dominant_pool(self):
        """returns the likelihood block with the highest confidence level"""
        try:
            tmp = max(self.sorted_likelihood_blocks, key=lambda block: block.CLs)
        except ValueError:
            tmp = None
        return tmp


    @property
    def likelihood_blocks(self):
        """The list of all component likelihood blocks extracted from the ``YODA`` file

        This attribute is the total information in the ``YODA`` file, but does not account for potential correlation/
        overlap between the members of the list

        **type** ( ``list`` [ :class:`~contur.factories.likelihood.Likelihood` ])
        """
        return self._likelihood_blocks
    
    @likelihood_blocks.setter
    def likelihood_blocks(self, value):
        self._likelihood_blocks = value



    @property
    def likelihood(self):
        """The full likelihood representing the ``YODA`` file in it's entirety

        **type** (:class:`~contur.factories.likelihood.CombinedLikelihood`)
        """
        return self._full_likelihood
    
    @likelihood.setter
    def likelihood(self, value):
        self._full_likelihood = value

    def __repr__(self):
        return "%s with %s blocks, holding %s" % (self.__class__.__name__, len(self.likelihood_blocks), self.likelihood)
