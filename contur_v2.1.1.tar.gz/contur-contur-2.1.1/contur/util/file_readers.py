import sys, os
import logging
import contur.config
import yoda, rivet



def get_histos(filename):
    """
    Get signal histograms from a generated YODA file.
    Loops over all yoda objects in the input file looking for valid signal histograms.

    Ignores REF and THY (which are read elsewhere) and RAW histograms.

    :Param filename: (```string```) name of yoda input file.

    Returns: 

    *   mchistos = dictionary containing {path, ao} pairs for candidate signal histograms.
    *   xsec     = yoda analysis object containing the generated xsec and its uncertainty
    *   Nev      = yoda analysis object containing sum of weights, sum of squared weight, number of events

    """
    
    mchistos = {}
    xsec = None
    Nev = None

    try:
        analysisobjects = yoda.read(filename)
    except Exception as e:
        contur.config.contur_log.error("Failed to read {}. {}".format(filename,e))
        return None, None, None

    contur.config.contur_log.info("Found {} analysisobjects in {}".format(len(analysisobjects),filename))
    for path, ao in analysisobjects.items():
        if path.startswith('/_EVTCOUNT'):
            Nev = ao
        if path.startswith('/_XSEC'):
            xsec = ao
        if os.path.basename(path).startswith("_"):
            continue
        if rivet.isRefPath(path):
            # Reference histograms are read elsewhere.
            continue
        if rivet.isRawPath(path):
            continue
        if rivet.isTheoryPath(path):
            # Theory histograms are read elsewhere.
            continue


        else:
            if path not in mchistos:
                mchistos[path] = ao

                
    if xsec is not None and Nev is not None:    
        contur.config.contur_log.info("Found {} potentially valid histograms in {}, with cross section {} pb".format(len(mchistos),filename,xsec.point(0).x()))
    else:    
        contur.config.contur_log.warning("Found {} potentially valid histograms in {}, but number of events or cross section could not be determined.".format(len(mchistos),filename))
        
    return mchistos, xsec, Nev

def read_herwig_out_file(root,files,matrix_elements):
    """ 
    Find the Herwig .out file and read cross sections for requested matrix element values from it.

    :param root: Top directory from which to  searching for .out files began
    :type root: string
    :param files: List of files being searches
    :param matrix_elements: list of matrix elements to look for
    :return: dictionary of matrix element (name, value) pairs

    """
    import re
    me_dict = {}

    for test_name in files:
        if test_name.endswith('.out'):
            out_file_path = os.path.join(root, test_name)

            for me in matrix_elements:
                with open(out_file_path, 'r') as out_file:
                    mename, mepatt = me, me
                    if "=" in me:
                        mename, mepatt = me.split("=")
                    thisxsec = 0.0
                    for line in out_file.readlines():
                        values = line.split()
                        if values and (values[0] == mepatt or re.match(mepatt, values[0])):
                            contur.config.contur_log.debug(line)
                            if values[3] != '0':
                                # dicking around to remove the error surrounded by brackets
                                num = values[3].split('(')[0]
                                exp = values[3].split(')')[1]
                                thisxsec = float(num+exp)
                                print(thisxsec)
                            else:
                                thisxsec = 0.0
                            me_dict.setdefault(mename, 0.0)
                            me_dict[mename] += thisxsec
                            print(me_dict.get(mename))
                    print(me_dict.get(mename))
    return me_dict

 
def read_herwig_log_file(root,files,branching_fractions,widths,masses):
    """
    Find the Herwig .log file and read various values from it

    :param root: Top directory from which to  searching for .out files began
    :type root: string
    :param files: List of files being searches
    :param branching_fractions: list of branching fractions to look for
    :param widths: list of branching widths to look for
    :param masses: list of branching masses to look for
    :return: dictionary of (name, value) pairs for the extracted parameters.


    """
    bf_dict = {}
    w_dict = {}
    m_dict = {}

    for test_name in files:
        if test_name.endswith('.log'):
            log_file_path = os.path.join(root, test_name)
            with open(log_file_path, 'r') as log_file:
                for line in log_file.readlines():
                    if branching_fractions is not None:
                        for bf in branching_fractions:
                            bf_store = "AUX:"+bf
                            if not bf==" "  and not bf_store in bf_dict and bf in line:
                                values = line.split()
                                contur.config.contur_log.debug(values)
                                bf_dict[bf_store] = values[2]
                                print(bf_dict[bf_store])

                    if widths is not None:
                        for w in widths:
                            w_store = "AUX:"+w
                            if "Parent" in line and not w==" " and not w_store in w_dict and w in line:
                                values = line.split()
                                contur.config.contur_log.debug(values)
                                lv = len(values)
                                w_dict[w_store] = values[lv-1]
                                contur.config.contur_log.info("Extracted Width for {} = {} GeV".format(w,w_dict[w_store]))

                    if masses is not None:
                        for m in masses:
                            m_store = "AUX:"+m
                            if "Parent" in line and not m==" " and not m_store in m_dict and m in line:
                                values = line.split()
                                contur.config.contur_log.debug(values)
                                lv = len(values)
                                m_dict[m_store] = values[lv-5]
                                print(m_dict[m_store])


    bf_dict.update(w_dict)
    bf_dict.update(m_dict)
    return bf_dict


def read_slha_file(root,slha_file,block_list):
    """ 
    read requested blocks from an SLHA1 file (if found) 

    returns a dictionary blocks_dict{ block: {name: value} } 
    for each block in block_list.

    the name of the block is prepended to each parameter, for disambiguation when
    written to the map file.

    for the MASS block the binwidth and binoffset will be applied, if provided.
    @TODO that would be better handled at the visualisation/plotting step?

    :param root: path to SLHA file
    :param slha_file: name of SLHA file
    :param block_list: list of SLHA blocks to read

    :return: dictionary  (blockname, (name, value))

    """

    import pyslha
    blocks_dict = {}

    shla_file_path = os.path.join(root, slha_file)
    if os.path.exists(shla_file_path):

        slha_file = open(shla_file_path, 'r')
        d = pyslha.read(slha_file)
        for block in block_list:
            tmp_dict = {}
            for k, v in d.blocks[block].items():
                if block == "MASS" and contur.config.binwidth > 0:
                    tmp_dict["{}:{}".format(block,k)]=contur.config.binoffset+contur.config.binwidth*int(abs(v)/contur.config.binwidth)
                else:
                    tmp_dict["{}:{}".format(block,k)]=v  
            blocks_dict[block]=tmp_dict

    else:
        contur.config.contur_log.warning("{} does not exist".format(shla_file_path))
        
              
    return blocks_dict



def read_param_point(file_path):
    """
    Read a parameter file and return dictionary of (strings of) contents

    :param file_path: full path the the parameter file
    :type file_path: string

    :return: dictionary of parameter (parameter_name, value) pairs

    """
    with open(file_path, 'r') as param_file:
        raw_params = param_file.read().strip().split('\n')

    param_dict = {}
    for param in raw_params:
        name, value = param.split(' = ')
        param_dict[name] = value

    return param_dict

def get_theory_ts(path):
    """
    read the SM vs measurement test statistics from the archived (.stat) file.

    :param path: YODA path of the relevant histogram.
    
    :return: the test statistic (`float`)
    

    """
    pool, lumi = contur.data.get_pool_info(path)
    if pool is None:
        return None
    
    parts = path.split("/")
    
    # build the file name
    ts_file = contur.config.path("data","Theory","sm_test",pool,parts[len(parts)-2],parts[len(parts)-1])
    ts_file = "{}.stat".format(ts_file)

    try:
        with open(ts_file, 'r') as file:
            info = file.readline().split()
        ts = float(info[1])        
        contur.config.contur_log.debug("Read test statistic file for {}. ts={}".format(path,ts))
        
    except FileNotFoundError:
        ts = None
        contur.config.contur_log.warn("Did not find: {}".format(ts_file))
        
    return ts

