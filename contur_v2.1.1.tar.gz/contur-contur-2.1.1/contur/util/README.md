Helper functions that may be used by more than one sub-package

* utils - genuinely miscellany

* functions to read various tpes of file used by contur.
  Should generally accept the file path (absolute, or relative to $CONTUR_ROOT) and return
  the desired content as a dictionary, unless stated otherwise


