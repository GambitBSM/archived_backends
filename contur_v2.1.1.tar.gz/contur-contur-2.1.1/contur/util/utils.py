# -*- python -*-

"""
Miscellaneous helper functions that may be used by more than one contur submodule

"""


import os
import numpy as np
import yoda
import rivet
import contur
from builtins import input
import logging

import scipy.stats as spstat

## Import the tqdm progress-bar if possible, otherwise fall back to a safe do-nothing option
try:
    from tqdm import tqdm as progress_bar
except ImportError:
    def progress_bar(iterable, **kwargs):
        return iterable

def mkoutdir(outdir):
    """
    Function to make an output directory if it does not already exist.
    Also tests if an existing directory is write-accessible.
    """
    if not os.path.exists(outdir):
        try:
            os.makedirs(outdir)
        except:
            msg = "Can't make output directory '%s'" % outdir
            raise Exception(msg)
    if not os.access(outdir, os.W_OK):
        msg = "Can't write to output directory '%s'" % outdir
        raise Exception(msg)

    
def write_banner():
    """
    Write an Ascii banner giving the version and pointing to the documenation
    """
    try:
        contur.config.contur_log.info("Running Contur version"+contur.config.version)
        contur.config.contur_log.info("See https://hepcedar.gitlab.io/contur-webpage/")
    except:
        print("Contur version {}".format(contur.config.version))
        print("See https://hepcedar.gitlab.io/contur-webpage/")

def write_summary_file(message, conturDepot):
    """
    Write a brief text summary of a conturDepot, describing the run conditions and results.
    If contur.config.gridMode is False, will also write info about the
    most sensitive histograms in each pool, for parsing by contur-mkhtml

    :param message: text (string) message containing the run conditions for this depot

    :param conturDepot: the processed depot of results

    the name of the directory to write the file into will be determined by contur.config.output_dir

    """

    mkoutdir(contur.config.output_dir)
    sumfn = open(os.path.join(contur.config.output_dir,contur.config.summary_file), 'w')

    if contur.config.gridMode:
        sumfn.write(message)
    else:

        # summary function will just read the first entry in the depot inbox
        if conturDepot.inbox[0].yoda_factory._full_likelihood.CLs is not None:
            result = "Combined exclusion for these plots is %.2f %% \n" % (
                    conturDepot.inbox[0].yoda_factory._full_likelihood.CLs * 100.0)
        else:
            result = "Could not evaluate exclusion for these data. Try turning off theory correlations?"

        sumfn.write(message + "\n" + result + "\n")
        sumfn.write("pools")
        for x in conturDepot.inbox[0].yoda_factory._sorted_likelihood_blocks:
            sumfn.write("\n{}".format(x.pools))
            sumfn.write("\n{:.8f}".format(x.CLs))
            sumfn.write("\n{}".format(rivet.stripOptions(x.tags)))

        contur.config.contur_log.info(result)

        sumfn.close()



def write_histo_dat(mcpath, plotparser, nostack, histo):
    """
    Write a YODA  .dat file (plot formatting) for the histogram in the output directory, for later display.

    :param mcpath: (`string`) the yoda path of the histogram 

    :param plotparser: (`rivet.PlotParser`) a standard rivet plot parser object.

    :param outdir: (`string`) 
        Absolute path to the top level directory for the output. 
        The dat files will be written in a directory structure below this as ``POOL/ANALYSIS/HISTOGRAM.dat``

    :param histo: dressed YODA ao
    :type histo: :class:`contur.factories.HistFactory`

    the output directort is detemined by contur.config.plot_dir

    """

    anaobjects = []
    drawonly = []
    if not mcpath.startswith("/"):
        mcpath = "/"+mcpath

    refdata = histo.refplot
    if histo.thyplot:
        theory = histo.thyplot

    try:
        if nostack:
            sigback = histo.sigplot
        else:
            sigback = histo.stack
    except AttributeError:
        sigback = None
            
    ## Check if we have reference data for the histogram
    if not histo.ref:
        contur.config.contur_log.warning("Not writing dat file for ".format(histo.signal.path()))
        return


    try:
        h = rivet.stripOptions(refdata.path()[4:])
    except TypeError as t:
        contur.config.contur_log.warning("Not writing dat file for {} ".format(histo.signal))
        return

    hparts = h.strip("/").split("/")
    hparts[0] = rivet.stripOptions(hparts[0])

    outdir = os.path.join(contur.config.plot_dir,histo.pool,hparts[0])
    mkoutdir(outdir)

    ratioreference = None

    refdata.setAnnotation('ErrorBars', '1')
    refdata.setAnnotation('PolyMarkers', '*')
    refdata.setAnnotation('ConnectBins', '0')
    drawonly.append('/REF' + h)
    anaobjects.append(refdata)

    if histo.thyplot:
        theory.setAnnotation('ErrorBars', '1')
        theory.setAnnotation('LineColor', 'green')
        theory.setAnnotation('ErrorBands','1')
        theory.setAnnotation('ErrorBandColor','green')
        theory.setAnnotation('ErrorBandOpacity','0.3')
        drawonly.append('/THY' + h)
        anaobjects.append(theory)

    plot = Plot()
        
    if contur.config.expectedLimit:
        refdata.setAnnotation('Title', 'SM')
        plot['RatioPlotYLabel'] = '(SM+BSM)/SM'
    else:
        refdata.setAnnotation('Title', 'Data')
        plot['RatioPlotYLabel'] = '(Bkgd+BSM)/Data'
        
    # write the bin number of the most significant bin, and the bin number for the plot legend
    if histo.CLs is not None and histo.CLs > 0:
        if histo.likelihood.index is not None:
            indextag=histo.likelihood.index
        else:
            indextag="Correlated all"
        if sigback is not None:
            sigback.setAnnotation('Title','[%s] %6.3f' % ( indextag, histo.CLs ))
        else:
            refdata.setAnnotation('Title','Data ([%s] %6.3f)' % ( indextag, histo.CLs ))
    else :
        if sigback is not None:
            sigback.setAnnotation('Title','No exclusion')
        else:
            refdata.setAnnotation('Title','Data. No exclusion')
            
    if sigback is not None:
        drawonly.append(mcpath + h)
        sigback.setAnnotation('Path', mcpath+h)
        sigback.setAnnotation('ErrorBars', '1')
        sigback.setAnnotation('LineColor', 'red')
        anaobjects.append(sigback)


    for key, val in plotparser.getHeaders(h).items():
        # Get any updated attributes from plotinfo files
        plot[key] = val


    plot['DrawOnly'] = ' '.join(drawonly).strip()
    plot['Legend'] = '1'
    plot['MainPlot'] = '1'
    #plot['LogY'] = '1'
    plot['RatioPlot'] = '1'
    plot['RatioPlotSameStyle'] = 0

    #plot['RatioPlotYMin'] = '0.0'
    # plot['RatioPlotMode'] = 'default'

    plot['RatioPlotMode'] = 'deviation'
    plot['RatioPlotYMin'] = '-3.0'
    plot['RatioPlotYMax'] = '3.0'

    plot['RatioPlotYLabel'] = '(Bkgd+BSM)/Data'

    plot['RatioPlotErrorBandColor'] = 'Yellow'

    ratioreference = '/REF'+rivet.stripOptions(h)
    plot['RatioPlotReference'] = ratioreference
    output = ''
    output += str(plot)
    from io import StringIO
    sio = StringIO()
    yoda.writeFLAT(anaobjects, sio)
    output += sio.getvalue()
    outfile = '%s.dat' % hparts[1]
    mkoutdir(outdir)
    outfilepath = os.path.join(outdir, outfile)
    f = open(outfilepath, 'w')
    f.write(output)
    f.close()


def write_sm_test(outdir, histo):
    """
    Write a short text file archiving the result of comparing
    SM prediction vs measurement (no signal prediction) for this histo.

    :param outdir: (`string`) 
        Absolute path to the top level directory for the output. 
        The .stat files will be written in a directory structure below this as ``POOL/ANALYSIS/HISTOGRAM.stat``

    :param histo: dressed YODA ao
    :type histo: :class:`contur.factories.HistFactory`

    """

    anaobjects = []

    refdata = histo.refplot
    theory = histo.thyplot

    hparts = refdata.path().strip("/").split("/")
    outdir = os.path.join(outdir, histo.pool, hparts[1])
    
    output = 'test_statistic {}\n'.format(histo.likelihood.ts_s_b)
    output += 'CLs {}\n'.format(histo.likelihood.CLs)

    outfile = '{}.stat'.format(hparts[2])
    mkoutdir(outdir)
    outfilepath = os.path.join(outdir, outfile)
    f = open(outfilepath, 'w')
    f.write(output)
    f.close()


    
def mkScatter2D(s1):
    """ 
    Make a Scatter2D from a Scatter1D by treating the points as y values and adding dummy x bins.
    """

    rtn = yoda.Scatter2D()

    xval = 0.5
    for a in s1.annotations():
        rtn.setAnnotation(a, s1.annotation(a))

    rtn.setAnnotation("Type", "Scatter2D");

    for point in s1.points():

        ex_m = xval-0.5
        ex_p = xval+0.5

        y = point.x()
        ey_p = point.xMax() - point.x()
        ey_m = point.x()    - point.xMin()

        pt = yoda.Point2D(xval, y, (0.5,0.5), (ey_p,ey_m))
        rtn.addPoint(pt)
        xval = xval + 1.0

    return rtn

def walklevel(some_dir, level=1):
    """
    Like os.walk but can specify a level to walk to
    useful for managing directories a bit better

    https://stackoverflow.com/questions/229186/os-walk-without-digging-into-directories-below
    """
    some_dir = some_dir.rstrip(os.path.sep)
    assert os.path.isdir(some_dir)
    num_sep = some_dir.count(os.path.sep)
    for root, dirs, files in os.walk(some_dir):
        yield root, dirs, files
        num_sep_this = root.count(os.path.sep)
        if num_sep + level <= num_sep_this:
            del dirs[:]


def newlogspace(start, stop, num=50, endpoint=True, base=10.0, dtype=None):
    """
    Numpy logspace returns base^start to base^stop, we modify this here so it returns logspaced between start and stop
    """
    return np.logspace(np.log(start)/np.log(base), np.log(stop)/np.log(base), num, endpoint, base, dtype)


def get_inspire(inspire_id):
    """
    Function to query InspireHEP database and return a dictionary containing the metadata

    extracted/adapted from rivet-findid

    :arg inspire_id: the ID of the publication on Inspire
    :type inspire_id: ``string``
    
    :return: pub_data ``dictionary`` -- selected metadata as a dictionary of bytes
    """

    try:
        from urllib.request import urlopen
    except ImportError:
        from urllib2 import urlopen
    import json
    url = "https://inspirehep.net/api/literature/{}".format(inspire_id)

    ## Get and test JSON
    try:
        response = urlopen(url)
    except Exception as e:
        contur.config.contur_log.error("Error opening URL {}: {}".format(url,e))
        return None

    metadata = json.loads(response.read().decode("utf-8"))
    if metadata.get("status", "") == 404:
        sys.stderr.write('ERROR: id {} not found in the InspireHEP database\n'.format(inspire_id))
        return None

    try:
        md=metadata["metadata"]
    except KeyError as ke:
        contur.config.contur_log.error("Could not find metadata for inspire ID {}".format(inspire_id))
        return None
        
    pub_data = {}

    pub_data['bibkey']=md["texkeys"][0]
    biburl = metadata["links"]["bibtex"]
    pub_data['bibtex']=urlopen(biburl).read()

    return pub_data

def permission_to_continue(message):
    """Get permission to continue program"""
    permission = ""
    while permission.lower() not in ['no', 'yes', 'n', 'y']:
        permission = str(input("{}\n [y/N]: ".format(message)))
        if len(permission)==0:
            permission = 'N'

    if permission.lower() in ['y', 'yes']:
        return True
    else:
        return False


class Plot(dict):
    ''' A tiny Plot object to help writing out the head in the .dat file '''

    def __repr__(self):
        return "# BEGIN PLOT\n" + "\n".join("%s=%s" % (k, v) for k, v in self.items()) + "\n# END PLOT\n\n"


def sort_blocks(likelihood_blocks, omitted_pools=""):
    """Function that sorts the list of likelihood blocks extracted from the ``YODA`` file

    This function implements the sorting algorithm to sort the list of all extracted :class:`~contur.factories.likelihood.Likelihood`
    blocks in the :attr:`likelihood_blocks` list, storing the reduced list in the :attr:`sorted_likelihood_blocks` list

    :Keyword Arguments:
        * *omittedPools* (``string``) --
          String of analysis pools to omit
    """
    if len(likelihood_blocks) == 0:
        raise ValueError('List of likelihood blocks passed is empty, the likelihood blocks list must contain at least one likelihood object')
    
    sorted_likelihood_blocks = []

    pools = []
    [pools.append(x) for x in [
        item.pools for item in likelihood_blocks] if x not in pools]
    for p in pools:
        if omitted_pools == p:
            continue
        anas = []
        [anas.append(x) for x in
         [contur.config.ANALYSIS.search(item.tags).group() for item in likelihood_blocks if
          item.tags and item.pools == p] if
         x not in anas]
        for a in anas:
            subpools = []
            for item in likelihood_blocks:
                if item.pools == p and a in item.tags:
                    if item.subpools not in subpools and item.subpools is not None:
                        subpools.append(item.subpools)

            if len(subpools) > 0:
                result = {}
                for sp in subpools:
                    result[sp] = contur.factories.CombinedLikelihood()

                for k, v in result.items():
                    # Remove the point if it ends up in a group
                    # Tags need to store which histo contribute to this point.
                    for y in likelihood_blocks:
                        if y.subpools == k and a in y.tags:
                            result[k].add_likelihood(y)
                            if len(result[k].tags) > 0:
                                result[k].tags += ","
                            result[k].tags += y.tags

                    v.calc_cls()
                    v.pools = p
                    v.tags = result[k].tags

                # add the max subpool back into the list of points with the pool tag set but no subpool
                [likelihood_blocks.append(v) for k, v in
                 result.items()]  # if v.CLs == max([z.CLs for z in result.values()])


   
    pool_list = []
    cls_list = []
    for x in likelihood_blocks:
        pool_list.append(x.pools)
        cls_list.append(x.CLs)
    
    # Create dictionary of empty lists
    combine_pool_cls_group = {}        
    for i in set(pool_list):
        combine_pool_cls_group[i] = []
    
    combine_pool_cls = list(zip(pool_list,cls_list))
    
    #Key is the pool pointing to list of CLs for pool
    for pair in combine_pool_cls:
        combine_pool_cls_group[pair[0]].append(pair[1])
    
    #Take the maximum CLS in each list
    for i in combine_pool_cls_group:
        combine_pool_cls_group[i] = max(combine_pool_cls_group[i])
    
    for p in pools:
        if not p == omitted_pools:
            for item in likelihood_blocks:
                if item.CLs == combine_pool_cls_group[p] \
                        and item.pools == p \
                        and item.pools not in [x.pools for x in sorted_likelihood_blocks]:
                    sorted_likelihood_blocks.append(item)
    
    return sorted_likelihood_blocks

def build_full_likelihood(sorted_blocks, omittedPool=""):
    """Function to build the full likelihood representing this entire ``YODA`` file

    This function takes the :attr:`sorted_likelihood_blocks` and combines them as statistically uncorrelated
    diagonal contributions to a :class:`~contur.factories.likelihood.CombinedLikelihood` instance which is stored
    as an attribute to this class as :attr:`likelihood`

    :Keyword Arguments:
        * *omittedPools* (``string``) --
          String of analysis pools to omit
    """
    if len(sorted_blocks) == 0:
        raise ValueError('List of sorted blocks passed is empty, the sorted blocks list must contain at least one likelihood object')

    full_likelihood = contur.factories.CombinedLikelihood()
    for x in sorted_blocks:
        if x.pools != omittedPool:
            full_likelihood.add_likelihood(x)
    full_likelihood.calc_cls()
    return full_likelihood

def likelihood_blocks_ts_to_cls(likelihood_blocks):
    """Function that calculates the confidence level for each 
       likelihood block extracted from the ``YODA`` file using the signal 
       and background test statistic for the block
    """
    if len(likelihood_blocks) == 0:
        raise ValueError('List of likelihood blocks passed is empty, the likelihood blocks list must contain at least one likelihood object')

    #Collect test statistics for each likelihood where the background 
    # test statistic is not none
    test_stats = {}

    for number, likehood_object in enumerate(likelihood_blocks):
        if likehood_object._ts_s_b is not None:
            test_stats[number] = (likehood_object._ts_s_b, likehood_object._ts_b)
    
    #Convert test statistics into p values
    test_stat_list = list(test_stats.values())
    p_values = np.exp(spstat.norm.logsf(np.sqrt(test_stat_list)))

    
    #Loop over each likelihood block, where p value exists evaluate confidence level
    # and update value of the ._CLs attribute for the likelihood block
    count = 0
    for ts_index, like_ob in enumerate(likelihood_blocks):
        if like_ob._s is None or like_ob._s.any(): #only done the below when we have signal events
            if ts_index in test_stats.keys():
                like_ob._p_s_b, like_ob._p_b = p_values[count]
                count +=1
                like_ob._CLs = like_ob.pval_to_cls([(like_ob._p_s_b, like_ob._p_b)])[0]
    
                if like_ob._CLs is not None:
                    like_ob._pval = 1.0-like_ob._CLs            
            else:
                like_ob._pval = None
                like_ob._CLs = None
                
            if like_ob._CLs is not None:
                if contur.config.contur_log.isEnabledFor(logging.DEBUG):
                    contur.config.contur_log.debug("Reporting CLs %f, pval %f, p_sb %f, p_b %f, ts_s_b %f, ts_b %f:" % (
                                           like_ob._CLs, like_ob._pval, like_ob._p_s_b, like_ob._p_b, like_ob._ts_s_b, like_ob._ts_b))
                
                if np.isnan(like_ob._CLs):
                    like_ob._CLs = None
                    contur.config.contur_log.warning(
                        "CLs evaluated to nan, set to None. {} ".format(like_ob._tags))
            else:
                contur.config.contur_log.warning(
                       "Could not evaluate CLs for {}".format(like_ob._tags))


def likelihood_blocks_find_dominant_ts(likelihood_blocks):
    """Function that finds the chi-square test statistic that gives the
       maximum confidence level for each likelihood block for which we
       don't have a valid covariance matrix (either the matrix has no 
       invserse or has not been succesfully built)
    """
    if len(likelihood_blocks) == 0:
        raise ValueError('List of likelihood blocks passed is empty, the likelihood blocks list must contain at least one likelihood object')

    
    #Collect chi-square test statistics for all likelihood for blocks for
    # which ._test_stats is not none, in addition collect index for each 
    # block (given by ._tags attribute) and the liklihood object block
    # itself
    chi_test = []
    likelihood_index = []
    like_blocks = {}
    
    for num, like_ob in enumerate(likelihood_blocks):
        if like_ob._test_stats is not None:
            chi_test = chi_test + like_ob._test_stats
            likelihood_index = likelihood_index + [num]*len(like_ob._test_stats)
            like_blocks[num] = like_ob
    
    #Convert test stats first to p-value and then confidence level
    p_values = np.exp(spstat.norm.logsf(np.sqrt(chi_test)))
    cls_list = likelihood_blocks[0].pval_to_cls(p_values)

    
    # For each likelihood block we want to find the test stats which give
    # the largest cls, we create a dictionary for both test stats and cls
    # where the keys are given by the likelihood block and each value is an 
    # empty list
    test_stats = {}
    cls = {}
    for tag in set(likelihood_index):
        test_stats[tag] = []
        cls[tag] = []
    
    #Now populate each list with the test stats and cls for the block
    for num, tag in enumerate(likelihood_index):
        test_stats[tag].append(chi_test[num])
        cls[tag].append(cls_list[num])
    
    #Loop over the blocks, for each block we find the index of the maximum
    # cls, we then update ._ts_s_sb and .ts_b with the test stat value using
    # the cls index
    for tag in set(likelihood_index):
        like_ob = like_blocks[tag]            
        like_ob._index = max(range(len(cls[tag])), key=cls[tag].__getitem__) + 1

        if contur.config.contur_log.isEnabledFor(logging.DEBUG):
            contur.config.contur_log.debug(
                "n data, {} signal, {} background {}, bin {} ".format(like_ob._n, like_ob._s, like_ob._bg, like_ob._index))
                                                                
        like_ob._ts_s_b, like_ob._ts_b = test_stats[tag][like_ob._index - 1]








