"""Global configuration class setting default behavior, importing contur loads all of the following

:Module members:

Where these are settable from the command line. See ```contur --help``` for documentation.

    * **buildCorr** (``bool``) see ```-u```
    * **useTheory** (``bool``) see ```--th```
    * **theoryOnly** (``bool``) see ```--to```
    * **useTheoryCorr** (``bool``) see ```--xtc```
    * **expectedLimit** (``bool``) see ```--el```

    * **vetoAnalyses** (``string``) see ```--ana-match```
    * **onlyAnalyses** (``string``) see ```--ana-unmatch```
    * **excludeMETRatio** (``bool``) see ```--xr```
    * **excludeHgg** (``bool``) see ```--xhg```
    * **excludeHWW** (``bool``) see ```--xhw```
    * **excludeAWZ** (``bool``) see ```--awz```
    * **excludeBVeto** (``bool``) see ```--wbv```
    * **excludeSearches** (``bool``) see ```-s```
    * **splitAnalysis** (``bool``) see ```--ana-split```

    * **gridMode** (``bool``) see ```-g```
    * **weight** (``string``) see ```--wn``

    * **binwidth** see ```--BW```
    * **binoffset** see ```--BO```
    * **blocklist** (default {"MASS","STOPMIX"}) see ```--S```


Stats/fitting, parameters, see ```contur --help```

    * **min_np**
    * **min_num_sys**
    * **min_syst**
    * **ll_prec**
    * **err_prec**
    * **n_iter**

Batch system

    * using_condor
    * condor_os
    * **using_qsub** (Default)
    * using_slurm

These are used by ```contur-plot```

    * contour_colour
    * mapfile (default "contur.map")
    * map_colorCycle (set to None, will be initialised from colour config if a pool name is unrecognised)

Default file names

    * mceg (default "herwig")
    * mceg_template (default "LHC.in")
    * paramfile (default "params.dat")
    * tag (default "runpoint\_")
    * unneeded_files (default ["LHC.run","Looptools.log", "py.py", "mgevents"])
      These files will be removed when runing ```contur-gridtool```
    * param_steering_file (default "param_file.dat")
    * summary_file (default Summary.txt)
    * output_dir (default ANALYSIS)

These are used internally, set from other conditions.

    * **refLoaded** (``bool``) --
      Flags whether the (yoda) reference data for this run has been loaded yet.

    * **silenceWriter** (``bool``) --
      Disables a lot of plotting output, for when it is not needed (eg in grid mode).

    * **contur_log** (``logging.logger``) logger object

"""
contur_log=None
logfile_name="contur.log"


def setup_logger(filename=logfile_name):
    """
    set up the logger object

    :param filename: name of log file
    """

    import logging, sys, contur.config
    contur.config.logfile_name=filename

    #for some reason we can't supply a formatter to the basic config: https://stackoverflow.com/questions/34319521/python-logging-module-having-a-formatter-causes-attributeerror
    logging.basicConfig(
        level=logging.ERROR,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        filemode="w",
        filename=contur.config.logfile_name,
    )

    stream = logging.StreamHandler(sys.stdout)
    FMT=logging.Formatter('%(levelname)s - %(message)s')
    stream.setFormatter(FMT)

    contur.config.contur_log=logging.getLogger()

    contur.config.contur_log.addHandler(stream)

    #if not contur.config.gridMode:
    #    dup_filter = _DuplicateFilter()
    #    contur.config.contur_log.addFilter(dup_filter)


#Setup some module level variable defaults
buildCorr=True
useTheory=False
theoryOnly=False
useTheoryCorr=True
expectedLimit=False

vetoAnalyses=[]
onlyAnalyses=[]
excludeMETRatio=False
excludeHgg=False
excludeHWW=True
excludeBVeto=True
excludeAWZ=True
excludeSearches=True

gridMode=False
splitAnalysis=False

weight=""

# minimum number of systematic uncertainty contributions before they will be treated as correlated
min_np=False
min_num_sys=2
min_syst=0.001
# termination criteria for scipy.minimize
ll_prec=0.0001
err_prec=0.0001
n_iter=200

refLoaded =False
found_ref ={}
silenceWriter=False #For API mode: disable file output

binwidth=-100.
binoffset=0.

using_condor=False
using_qsub  =True
using_slurm =False

condor_os = "CentOS7"

mceg="herwig"
mceg_template="LHC.in"
default_nev=30000

version="2.1.0"

# plotting config.
contour_colour="white"
map_colorCycle=None

# Some default filenames.
paramfile="params.dat"
tag="runpoint_"
unneeded_files=["LHC.run","Looptools.log", "py.py", "mgevents"]
blocklist={"MASS","STOPMIX"}
mapfile="contur.map"
param_steering_file="param_file.dat"
summary_file="Summary.txt"
grid_summary_file="GridSummary.txt"
output_dir="ANALYSIS"
import os
plot_dir=os.path.join(output_dir,"plots")
grid=None
results_dbfile=None
models_dbfile=None


import re
# This allows for the form EXPERIMENT_YEAR_INSPIRENUMBER or EXPERIMENT_PHYSICSGROUP_YEAR_ID
APATT=r'(([A-Z0-9]+_\d{4}_[IS]\d{5,8})|([A-Z0-9]+_[A-Z]{4}_\d{4}_[A-Z0-9]+)'
ANALYSISPATTERN = re.compile(APATT+r')')
ANALYSIS        = re.compile(r'('+APATT+r')[^/]*)')
ANALYSISHISTO   = ANALYSISHISTO   = re.compile(r'('+APATT+r')[^/]*)/((d\d+-x\d+-y\d+)|\w+)')

# reference data
refObj = {}
thyObj = {}
refCorr = {}
refUncorr = {}
refErrors = {}
theoryCorr = {}
theoryUncorr = {}
theoryErrors = {}
theoryTS = {}

# A one-off to hold objects that have been scaled in an unscaled form for plotting
plotObj = {}
plotThObj = {}




class _DuplicateFilter(object):
    """
    Private class to filter log messages so only one instance shows once, from:
    from https://stackoverflow.com/questions/31953272/python-logging-print-message-only-once
    """
    def __init__(self):
        self.msgs = set()

    def filter(self, record):
        rv = record.msg not in self.msgs
        self.msgs.add(record.msg)
        return rv
