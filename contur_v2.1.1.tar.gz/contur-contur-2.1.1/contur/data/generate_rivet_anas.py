import os, glob
import rivet
import contur
import subprocess

def write_sm_file(ana_name,pool,out_dir,text_string):
    """
    Write an rst file describing the theory predictions available for this analysis.

    :param ana_name: name of the analysis (including any rivet option string)
    :param out_dir: name of the directory the write to
    :param text_string: an rst-style link, with text, will be appended to this and returned.

    """    

    th_desc = contur.data.getTheoryDescription(ana_name)
    ana_file_stem = ana_name.replace(":","_").replace("=","_")
    ana_file_out = os.path.join(out_dir,"SM",ana_file_stem+".rst")
    dat_file_dir = contur.config.path('data','Theory','sm_test',pool,rivet.stripOptions(ana_name))

    if th_desc:
        text_string += " SM theory predictions are available :doc:`here <SM/{}>`.\n".format(ana_file_stem)
        th_str = ":orphan:\n\nStandard Model Predictions for {}\n{}\n\n".format(ana_file_stem,"="*(31+len(ana_file_stem)))
        for prediction in th_desc:
            insp_ids = prediction[0].split(',')
            bibkeys = ""
            for insp_id in insp_ids:
                paper_data = contur.util.get_inspire(insp_id) 
                try:
                    bibkeys+=str(paper_data['bibkey'])
                    bibkeys+=','
                except Exception as e:
                    print("Could not find bibtex key for inspire ID {} {}".format(insp_id,e))

            if len(bibkeys)>0:
                th_str += "\n {} :cite:`{}`: {} \n\nStored in file: {} \n".format(prediction[3],bibkeys[:-1],prediction[4],prediction[2])
            else:
                th_str += "\n {} (Could not find bibtex key) {} \n\nStored in file: {} \n".format(prediction[3],prediction[4],prediction[2])

        th_str += "\n"

        # now make the figures
        ana_file_dir = os.path.join(out_dir,"SM",ana_file_stem)
        contur.util.mkoutdir(ana_file_dir)
        mp_command = ["make-plots"]
        mp_command.append("-f")
        mp_command.append("png")
        mp_command.append("-o")
        mp_command.append(ana_file_dir)
        for dat_file in glob.glob(os.path.join(dat_file_dir,"*.dat")):
            mp_command.append(dat_file)
            th_str += ".. figure:: "+ana_file_stem+"/"+os.path.basename(os.path.splitext(dat_file)[0])+".png"+"\n           :scale: 80%\n\n"

        subprocess.Popen(mp_command).wait()
        ana_file = open(ana_file_out, 'w')
        ana_file.write(th_str)
        
    else:
        text_string += ":red:`No SM theory predictions available for this analysis.` \n"

    return text_string

def generate_rivet_anas(output_directory,webpages):
    """
    Generate various rivet analysis listings from the Contur database.

    - the .ana files for Herwig running

    - the script to set the analysis list environment variables

    - (optionally) the contur webpage listings.

    :param output_directory: directory to write the shared files.
    :param webpages: if true, also write out the contur webpage listings.
    
    """
    # statics
    rivettxt = "insert Rivet:Analyses 0 "

    # make the directory if it doesn't already exist
    contur.util.mkoutdir(output_directory)
    contur.util.mkoutdir(output_directory+"/SM")

    # get the lists of analyses
    aLists = contur.data.getAnalyses()

    # open file for the environment setters
    fl = open(output_directory + "/analysis-list", 'w')

    known_beams = contur.data.getBeams()
    envStrings = {}

    # build the .ana and env variable setters
    for beam in contur.data.getBeams():
        analysis_list = contur.data.getAnalyses(beam=beam) 
        f = open(os.path.join(output_directory, beam + ".ana"), 'w')
        envStrings[beam] = "export CONTUR_RA" + beam + "=\""
        for analysis in analysis_list:
            ana = rivet.AnalysisLoader.getAnalysis(rivet.stripOptions(analysis))
            if ana is not None:
                f.write(rivettxt + analysis + " # " + ana.summary() + "\n")
                envStrings[beam] = envStrings.get(beam) + analysis + ","
            else:
                print("No analysis found for {}".format(analysis))

    for estr in envStrings.values():
        estr = estr[:len(estr) - 1] + "\""
        fl.write(estr + "\n \n")
        
    if not webpages:
        return

    web_dir = os.getenv('CONTUR_WEBDIR')
    if web_dir == None:
        web_dir = output_directory
    else:
        web_dir = os.path.join(web_dir,"datasets")

    # style stuff
    style_stuff = ".. raw:: html \n \n <style> .red {color:red} </style> \n \n.. role:: red\n\n"

    # open file for the web page list
    data_list_file = open(os.path.join(web_dir,"data-list.rst"), 'w')
    data_list = "Current Data \n------------ \n"

    bvetoissue = "\nb-jet veto issue\n---------------- \n\n *The following measurements apply a detector-level b-jet veto which is not part of the particle-level fiducial definition and therefore not applied in Rivet. Also applies to CMS Higgs-to-WW analysis. Off by default, can be turned on via command-line, but use with care.* \n"

    higgsww = "\nHiggs to WW\n----------- \n\n *Typically involve large data-driven top background subtraction. If your model contributes to the background as well the results maybe unreliable. Off by default, can be turned on via command-line.* \n"

    higgsgg = "\nHiggs to diphotons\n------------------ \n\n *Higgs to two photons use a data-driven background subtraction. If your model predicts non-resonant photon production this may lead to unreliable results. On by default, can be turned off via command-line.* \n"

    ratios = "\nRatio measurements\n------------------ \n\n *These typically use SM theory for the denominator, and may give unreliable results if your model contributes to both numerator and denominator. On by default, can be turned off via command-line.* \n"

    searches = "\nSearches\n-------- \n\n *Detector-level, using Rivet smearing functions. Off by default, can be turned on via command-line.*\n"

    nutrue = "\nNeutrino Truth\n-------------- \n\n *Uses neutrino flavour truth info, may be misleading for BSM. Off by default, can be turned on via command-line.*\n"

    pools = contur.data.getPools()

    current_pool = ""

    for ana in sorted(pools, key=pools.get):

        if len(pools[ana]) > 0:

            analysis_name = rivet.stripOptions(ana)

            pool_str = "\n Pool: **" + pools[ana] + "**  *" + \
                       contur.data.getDescription(pools[ana]) + "* \n\n"
            tmp_str = "   * `" + ana + " <https://rivet.hepforge.org/analyses/" + \
                      analysis_name + ".html>`_, "
            analysisObj = rivet.AnalysisLoader.getAnalysis(analysis_name)
            if analysisObj is not None:
                tmp_str += "{} :cite:`{}`. ".format(analysisObj.summary(),analysisObj.bibKey())
            else:
                tmp_str += "Could not find this analysis in your Rivet install"
                print(
                    "Could not find %s in your Rivet install. Update Rivet, or add the analysis to the data/Rivet directory" % ana)

            tmp_str = write_sm_file(ana,pools[ana],web_dir,tmp_str)
                
            if contur.data.hasRatio(ana):
                if pools[ana] in ratios:
                    ratios += tmp_str
                else:
                    ratios += pool_str + tmp_str

            elif contur.data.hasSearches(ana):
                if pools[ana] in searches:
                    searches += tmp_str
                else:
                    searches += pool_str + tmp_str

            elif contur.data.hasHiggsgg(ana):
                if pools[ana] in higgsgg:
                    higgsgg += tmp_str
                else:
                    higgsgg += pool_str + tmp_str

            elif contur.data.hasHiggsWW(ana):
                if pools[ana] in higgsww:
                    higgsww += tmp_str
                else:
                    higgsww += pool_str + tmp_str

            elif contur.data.hasNuTrue(ana):
                if pools[ana] in nutrue:
                    nutrue += tmp_str
                else:
                    nutrue += pool_str + tmp_str

            else:
                if pools[ana] in data_list:
                    data_list += tmp_str
                else:
                    data_list += pool_str + tmp_str

            if contur.data.hasBVeto(ana):
                if pools[ana] in bvetoissue:
                    bvetoissue += tmp_str
                else:
                    bvetoissue += pool_str + tmp_str


    data_list_file.write(style_stuff)
    data_list_file.write(data_list)
    data_list_file.write(ratios)
    data_list_file.write(higgsgg)
    data_list_file.write(searches)
    data_list_file.write(nutrue)
    data_list_file.write(higgsww)
    data_list_file.write(bvetoissue)

    print("Analysis and environment files written to %s" % output_directory)
