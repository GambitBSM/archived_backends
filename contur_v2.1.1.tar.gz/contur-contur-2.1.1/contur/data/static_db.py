import re
import sqlite3 as db
import os
from os.path import dirname, join
import rivet

import contur
from rivet.aopaths import AOPath

# TODO: Rewrite using an RAII idiom
# TODO: Explain what that would actually mean.

INIT = False
INVALID = (-1, '', '')
known_beams = []
pool_beam = {}
pool_desc = {}
lumis = {}
pools = {}
beams = {}
whitelists = {}
blacklists = {}
needtheory = {}
higgsgg = {}
higgsww = {}
bveto = {}
atlaswz = {}
searches = {}
metratio = {}
aLists = {}


class listdict(dict):
    """ Dictionary which returns an empty list if the key is missing. """ 
    def __missing__(self, key):
        self[key] = []
        return self[key]


subpools = listdict()
norms = listdict()
nxdiffs = listdict()
theory_predictions = listdict()


def init_dbs():
    """ 
    The principle function to read the database and populate dictionaries using the data.
    it is invoked by the first access request. 
    """

    dbfile = contur.config.path('data', 'DB', 'analyses.db')
    conn = db.connect(dbfile)
    c = conn.cursor()

    for row in c.execute('SELECT id FROM beams GROUP BY id;'):
        beam = row[0]
        known_beams.append(beam)

    for row in c.execute('SELECT pool,beam,description FROM analysis_pool;'):
        pool, beam, description = row
        pool_beam[pool] = beam
        pool_desc[pool] = description

    for row in c.execute('SELECT id,lumi,pool FROM analysis;'):

        ana, lumi, pool = row
        lumis[ana] = lumi
        if pool:
            pools[ana] = pool
            beam = pool_beam.get(pool)
            beams[ana] = beam
            if not beam in aLists.keys():
                aLists[beam] = []
            aLists[beam].append(ana)
        else:
            pools[ana] = ''
            beams[ana] = ''

    for row in c.execute('SELECT id,group_concat(pattern) FROM whitelist GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        whitelists[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM blacklist GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        blacklists[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM needtheory GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        needtheory[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM higgsgg GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        higgsgg[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM searches GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        searches[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM higgsww GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        higgsww[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM bveto GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        bveto[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM atlaswz GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        atlaswz[ana] = patterns

    for row in c.execute('SELECT id,group_concat(pattern) FROM metratio GROUP BY id;'):
        ana, patterns = row
        patterns = patterns.split(',')
        metratio[ana] = patterns

    for row in c.execute('SELECT id,pattern,subid FROM subpool;'):
        ana, pattern, subid = row
        #        subid = 'R%s' % (subid + 1)
        subpools[ana].append((pattern, subid))

    for row in c.execute('SELECT id,pattern,norm,nxdiff FROM normalization;'):
        ana, pattern, norm, nxdiff = row
        norms[ana].append((pattern, norm, nxdiff))
        #nxdiffs[ana].append((pattern, nxdiff))

    for row in c.execute('SELECT id,inspids,pattern,file_name,short_description,long_description FROM theory_predictions;'):
        ana, inspids, pattern, file_name, short_description, long_description  = row
        theory_predictions[ana].append((inspids, pattern, file_name, short_description, long_description))

    conn.close()

    global INIT
    INIT = True


class InvalidPath(Exception):
    pass


def splitPath(path):
    """
    Take a yoda histogram path and return the analysis name and the histogram name
    """
    m = contur.config.ANALYSISHISTO.search(path)
    if not m:
        contur.config.contur_log.debug("{} is not a valid path".format(path))
        raise InvalidPath
    else:
        analysis = m.group(1)
        tag = m.group(0).split("/")[1]
    return analysis, tag


def validHisto(h, gotTheory=True):
    """
    Tests a histo path to see if it is a valid contur histogram for this run (taking into account
    the run time flags).
    """
    if not INIT:
        init_dbs()

    try:
        ana, tag = splitPath(h)
    except InvalidPath:
        return False

    try:
        aop = AOPath(h)
        if aop.istmp() or aop.israw():
            return False
    except:
        return False

    if ana in searches and contur.config.excludeSearches:
        for pattern in searches[ana]:
            if pattern in tag:
                return False

    if ana in higgsgg and contur.config.excludeHgg:
        for pattern in higgsgg[ana]:
            if pattern in tag:
                return False

    if ana in higgsww and contur.config.excludeHWW:
        for pattern in higgsww[ana]:
            if pattern in tag:
                return False

    if ana in bveto and contur.config.excludeBVeto:
        for pattern in bveto[ana]:
            if pattern in tag:
                return False

    if ana in atlaswz and contur.config.excludeAWZ:
        for pattern in atlaswz[ana]:
            if pattern in tag:
                return False

    if isRatio(h) and contur.config.excludeMETRatio:
        return False

    if ana in lumis:
        if ana not in whitelists:
            if ana not in blacklists:
                return True
            elif ana in blacklists:
                for pattern in blacklists[ana]:
                    if pattern in tag:
                        return False
                return True
        elif ana in whitelists:
            for pattern in whitelists[ana]:
                if pattern in tag:
                    return True
            return False
    else:
        return False

def get_pool_info(path):
    """ 
    Given the yoda path of a histogram, return the pool and the associated integrated lumi.
    """

    if not INIT:
        init_dbs()
    
    pool = None
    lumi = None
    parts = path.split('/')
    ana = parts[(len(parts)-2)]
    try:
        pool = pools[ana]
        lumi = lumis[ana]
        name = parts[(len(parts)-1)]
        for full_ana, patterns in whitelists.items():
            if ana in full_ana:
                pool, lumi = None, None
                for pattern in patterns:
                    if pattern in name:
                        pool = pools[full_ana]
                        lumi = lumis[full_ana]
                        return pool, lumi
        for full_ana, patterns in blacklists.items():
            if ana in full_ana:
                for pattern in patterns:
                    if pattern in name:
                        contur.config.contur_log.warning("Cant find pool for {}".format(path))
                        return None, None
                    
    except KeyError:
        # generally means this analysis is in more than one pool, with different running modes.
        # have to work a bit harder in that case; it should be in a whitelist.
        name = parts[(len(parts)-1)]        
        # first, if this histo whitelisted for some pool, got the pool and return
        for full_ana, patterns in whitelists.items():
            if ana in full_ana:
                for pattern in patterns:
                    if pattern in name:
                        pool = pools[full_ana]
                        lumi = lumis[full_ana]
                        return pool, lumi

        # if this histo blacklisted, not here
        for full_ana, patterns in blacklists.items():
            if ana in full_ana:
                for pattern in patterns:
                    if pattern in name:
                        contur.config.contur_log.warning("Cant find pool for {}".format(path))
                        return None, None

                    
        contur.config.contur_log.warning("Cant find pool for {}.".format(path))
        
    return pool, lumi
        
def LumiFinder(h):
    """
    Get the integrated luminosity, pool and subpool for a valid contur histogram. Else return INVALID.

    :param h: (``string``) yoda histogram path

    """
    if not INIT:
        init_dbs()

    try:
        ana, tag = splitPath(h)
    except InvalidPath:
        return INVALID

    try:
        pool, lumi = get_pool_info(h)
        if contur.config.splitAnalysis:
            pool = tag
    except KeyError:
        return INVALID

    if ana in whitelists and tag:
        ok = False
        for pattern in whitelists[ana]:
            if pattern in tag:
                ok = True
                break
 
        if not ok: return INVALID

    if ana in blacklists:
        for pattern in blacklists[ana]:
            if pattern in tag:
                return INVALID

    subpool = None
    if ana in subpools:

        for p, subid in subpools[ana]:
            if re.search(p, tag):
                subpool = subid
                if contur.config.splitAnalysis:
                    pool = subid
                break

    return lumi, pool, subpool


def isNorm(h):
    """
    :param h: (``string``) histogram path.

    Returns:

    * **isScaled** - does this histogram need to be scaled to turn it into a differential cross section?

    * **scaleFactor** - the scale factor, if so (=1 otherwise)

    * **nev_differential** - factor for converting "number of events per something" plots (searches) into number of events. See ``analysis.sql`` for detailed description.

    """
    if not INIT:
        init_dbs()

    ana, tag = splitPath(h)

    isNorm = False
    normFac = 1.0
    nx_diff = 0

    # need to do it this way because for ref data ana does not have the MODE attached.
    for s in norms:
        if ana in s:
            for p, norm, nxdiff in norms[s]:
                if re.search(p, tag):
                    if norm > 0:
                        isNorm = True
                        normFac = norm
                    nx_diff = nxdiff
                    break

    return isNorm, normFac, nx_diff

# Better-named alias, since this isn't just a boolean-test function
getNormInfo = isNorm


def isRatio(h):
    """
    Is this a ratio plot?
    :param h: (``string``) yoda histogram path
    
    """

    if not INIT:
        init_dbs()

    try:
        ana, tag = splitPath(h)
    except InvalidPath:
        return False

    if ana in metratio:
        for pattern in metratio[ana]:
            if pattern in tag:
                return True

    return False

# More-specific alias
isMETRatio = isRatio
" Is this a missing energy ratio plot? "

def hasRatio(ana):
    "Does this analysis have ratio measurements?"
    if not INIT:
        init_dbs()

    # Hard-coded!
    if ana in metratio:
        return True

    return False

# More-specific alias
hasMETRatio = hasRatio
"Does this analysis have missing-energy ratio measurements?"


def hasSearches(ana):
    "Does this analysis have search measurements?"
    if not INIT:
        init_dbs()

    if ana in searches:
        return True

    return False

def isSearch(h):
    """

    Is this a search event-count plot?

    :param h: (``string``) yoda histogram path

    """
    if not INIT:
        init_dbs()

    try:
        ana, tag = splitPath(h)
    except InvalidPath:
        return False

    if ana in searches:
        for pattern in searches[ana]:
            if pattern in tag:
                return True

    return False


def hasBVeto(ana):
    "Does this analysis have measurements with a b-jet-veto problem?"
    if not INIT:
        init_dbs()

    if ana in bveto:
        return True

    return False

def hasNuTrue(ana):
    "Does this analysis have measurements with a truth-neutrino problem?"
    if not INIT:
        init_dbs()

    if ana in atlaswz:
        return True

    return False


def hasHiggsgg(ana):
    "Does this analysis have Higgs -> photons measurements?"
    if not INIT:
        init_dbs()

    if ana in higgsgg:
        return True

    return False


def hasHiggsWW(ana):
    "Does this analysis have Higgs -> WW measurements?"
    if not INIT:
        init_dbs()

    if ana in higgsww:
        return True

    return False


def theoryComp(h):
    """
    If this histogram **always** requires a SM theory comparison, return True.

    :param h: (``string``) yoda histogram path

    """
    if not INIT:
        init_dbs()

    ana, tag = splitPath(h)

    if ana in needtheory:
        for pattern in needtheory[ana]:
            if pattern in tag:
                return True

    return False


def getAnalyses(pool=None, beam=None):
    """ 
    Return a list of rivet analyses in the input pool. If no pool supplied, return all the ones Contur knows with
    the supplied beam. If no beam, return all of them regardless of beam or pool.

    """

    if not INIT:
        init_dbs()

    if pool:
        analyses = []
        for ana in pools:
             #anaNoMode = ana.split(':')[0]  # remove potential mode of analysis
             #if anaNoMode in analyses:  # different mode of analysis already added
             #   continue
            condition = (pools[ana] != pool or
                         (hasSearches(ana) and contur.config.excludeSearches) or
                         (hasHiggsgg(ana) and contur.config.excludeHgg) or
                         (hasHiggsWW(ana) and contur.config.excludeHWW) or
                         (hasNuTrue(ana) and contur.config.excludeAWZ) or
                         (hasBVeto(ana) and contur.config.excludeBVeto))
            if condition:
                continue
            analyses.append(ana)
        return analyses

    else:
        analyses = []
        if beam in aLists:
            return aLists[beam]
        elif beam:
            if (contur.config.contur_log):
                contur.config.contur_log.warning("Warning: No analyses for given beam {}. Returning empty list".format(beam))
            else:
                print ("Warning: No analyses for given beam {}. Returning empty list".format(beam))
            return []
        else:
            for anas in aLists.values():
                for ana in anas:
                    analyses.append(ana)

        return analyses


def getPools():
    "Get the full list of analysis pools"
    if not INIT:
        init_dbs()
    return pools


def getBeams(pool=None):
    "Get the list of beam known configurations, specific to the named pool if given"
    if not INIT:
        init_dbs()

    if not pool: 
        return known_beams

    beams = []
    expt, energy, sig = pool.split("_")
    for beam in known_beams:
        if energy in beam and expt in ["ATLAS", "CMS", "LHCb", "ALICE"]:
            return [beam]
    contur.config.contur_log.error("No beam found for pool {}".format(pool))
    return None


def getDescription(pool):
    "Get a short description of the named pool"
    if not INIT:
        init_dbs()
    return pool_desc[pool]


def getTheoryDescription(ana):
    " Retrun a list of the SM theory predictions for this analysis (if any). Otherwise return ``False``."
    if not INIT:
        init_dbs()
    if ana in theory_predictions:
        return theory_predictions[ana]
    else:
        return False
