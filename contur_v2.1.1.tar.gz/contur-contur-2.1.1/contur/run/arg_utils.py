from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
import sys, os
import contur
from shutil import copyfile
import logging


def get_args(argv, arg_group="unknown argument group"):
    """Parse command line arguments"""

    parser = get_argparser(arg_group)
    args = parser.parse_args(argv)
    return args


def get_argparser(arg_group):
    """ 
    Build and return an argument parser 

    :param arg_groups: which argument groups will be used.

    * group **mapplot** for plotting map files
    * group **analysis** for running analysis on a gird or a single yoda file
    * group **smtest** for running statistical tests on SM theory
    * group **gridtools** for running grid utilities

    """

    known_groups = {}
    known_groups['smtest'] = ['stats', 'select', 'smplots']
    known_groups['mapplot'] = ['map_plotting']
    known_groups['analysis'] = ['io', 'dress', 'select', 'stats']
    known_groups['gridtools'] = ['tools', 'batch']
    known_groups['batchsub'] = ['batch']

    if arg_group not in known_groups.keys():
        print("Do not recognize the requested argument group: {}".format(arg_group))
        sys.exit(1)

    active_groups = []
    for flag in known_groups[arg_group]:
        active_groups.append(flag)

    if arg_group == 'batchsub':
        parser = ArgumentParser(description=(
            "Run a parameter space scan and submit batch jobs.\n"
            "Produces a directory for each beam containing generator config file detailing the "
            "parameters used at that run point and a shell script to run the generator "
            "that is then submitted to batch.\n"
            "\n"), formatter_class=ArgumentDefaultsHelpFormatter)

    elif arg_group == 'mapplot':
        parser_description = ("Plot contur data from a .map file.\n")
        parser = ArgumentParser(usage=__doc__, description=parser_description,
                                formatter_class=ArgumentDefaultsHelpFormatter)
    else:

        parser = ArgumentParser(
            usage=__doc__, formatter_class=ArgumentDefaultsHelpFormatter)

    # generic arguments, always allowed.
    parser.add_argument("-v", "--version", action="store_true", dest="printVersion",
                        default=False, help="print version number and exit.")
    parser.add_argument("-d", "--debug", action="store_true", dest="DEBUG", default=False,
                        help="Switch on Debug to all, written to log file")
    parser.add_argument("-q", "--quiet", action="store_true", dest="QUIET", default=False,
                        help="Suppress info messages")
    parser.add_argument("-l", "--logfile", dest="LOG",
                        default=contur.config.logfile_name, help="Specify logfile name.")

    if "map_plotting" in active_groups:
        # Positional arguments
        parser.add_argument('map_file', type=str, help=('Path to .map file '
                                                        'containing list of depot objects.'))
        parser.add_argument('variables', nargs='*', type=str,
                            help=('x, y [and z] variables to plot.'))

        # Optional arguments
        parser.add_argument('-o', '--output_path', type=str, default='conturPlot', dest="OUTPUTDIR",
                            help="Path to output plot(s) to.")

        parser.add_argument('-ef', "--externalFunction", type=str, default=None,
                            help="Python file with external functions to load and plot")
        parser.add_argument('-eg', "--externalGrid", type=str, default=None,
                            help="Python file loading alternative external grids")

        parser.add_argument('-xl', "--xlog", action="store_true",
                            help="Set the xaxis to be displayed on a log scale")
        parser.add_argument('-yl', "--ylog", action="store_true",
                            help="Set the yaxis to be displayed on a log scale")
        parser.add_argument('--pools', dest="plot_pools", action='store_true',
                            help="Turn on plotting of individual analysis pools (much slower!)")
        parser.add_argument('-O', '--omit', type=str,
                            help='Name of pool to omit (will slow things down!)', default="")

        parser.add_argument('-x', '--xlabel', type=str, default=None,
                            help='x-axis label. Accepts latex formatting but special characters must be input with a slash, e.g. \$M\_\{z\'\}\$~\[GeV\]')
        parser.add_argument('-y', '--ylabel', type=str, default=None,
                            help='y-axis label. Accepts latex formatting but special characters must be input with a slash, e.g. \$M\_\{z\'\}\$~\[GeV\]')
        parser.add_argument('-sp', '--save_plots', action='store_true',
                            help="Save the raw matplotlib axes to a file for graphical manipulation")
        parser.add_argument('-T', '--title', type=str,
                            help='Title for plot.', default="")
        parser.add_argument('-L', '--ilevel', '--iLevel', type=int,
                            help='interpolation zoom level', default=3)
        parser.add_argument('--style', dest="style", default="DRAFT", choices=[
            "DRAFT", "FINAL"], type=str.upper,
                            help="Global flag for plot-styling variations: 'final' will have no title or cmap key and will produce a .tex file containing a colour legend for the dominant pools plot")
        parser.add_argument('--isigma', '--iSigma', type=float,
                            help='interpolation smoothing radius, in mesh cells', default=0.75)
        parser.add_argument('--num-dpools', dest="ndpools", type=int,
                            help='Number of levels of (sub)dominant pool plots to make.', default=1)
        parser.add_argument('--clstxt', dest="showcls", default=False, action="store_true",
                            help="Write CLs values on top of the mesh in the detailed dominant-pool plots.")
        parser.add_argument('--no-clsdpool', dest="simplecls", default=False, action="store_true",
                            help="Skip the detailed dominant-pool plot with lead/sub/diff CLs meshes.")
        parser.add_argument('-c', '-contour_colour', dest="contour_colour", default=contur.config.contour_colour,
                            type=str, help="Colour for the 68/95 contours")

    if "smplots" in active_groups:
        parser.add_argument("-o", "--outputdir", dest="OUTPUTDIR",
                            default="sm_plots", help="Specify output directory for SM plot files.")

    if "io" in active_groups:
        io = parser.add_argument_group("Input/Output control options")
        io.add_argument('yoda_files', nargs='*', metavar='yoda_files',
                        help='.yoda files to process.')
        io.add_argument("-o", "--outputdir", dest="OUTPUTDIR",
                        default=contur.config.output_dir, help="Top level output directory.")
        io.add_argument("-y", "--yodamerge",
                        action="store_true", dest="MERGEONLY", default=False,
                        help="only do the yodamerge step, then exit ")
        io.add_argument("--ns", "--nostack",
                        action="store_true", dest="NOSTACK", default=False,
                        help="in single run mode, do not stack the histograms in dat file output")
        io.add_argument("-g", "--grid", dest="GRID", default=None,
                        help="specify a folder containing a structured grid of points"
                             " to analyse. Usually 'myscan'.")
        io.add_argument('-T', '--tag', dest='TAG', default=contur.config.tag,
                        help='Identifier for merged yoda files.')
        io.add_argument("-m", "--map", dest="MAPFILE", default=contur.config.mapfile,
                        help="Name of map file output in grid running.")
        io.add_argument("-rn", "--runname", dest="RUNNAME", default=None,
                        help="Unique indentifier for each run, for example author name")
        io.add_argument("--new", action="store_true",
                        help="Force Contur to not use possibly available merges of yoda files but merge yoda files anew.")
        io.add_argument("-db", "--initDB", action="store_true", dest="INIT_DB", default=False,
                             help="init responsive db for grid mode")


        
    if "dress" in active_groups:
        dress = parser.add_argument_group("Dressing options to embelish outputs")
        dress.add_argument("-p", "--param_file", dest="PARAM_FILE", default="params.dat",
                           help="Optionally specify a parameter file. Only used for documentation, and ignored for grid running.")
        dress.add_argument("--model", dest="MODEL",
                           help="Optionally give name for model used. Only used for documentation.")
        dress.add_argument("--bf", "--branchingfraction", dest="BF",
                           help="Optionally give a comma-separated list of branching fractions for which cross sections will be stored in the map file")
        dress.add_argument("--me", "--matrixelement", dest="ME",
                           help="Optionally give a comma-separated list of matrix elements for which cross sections will be stored in the map file")
        dress.add_argument("-w", "--width", dest="WIDTH",
                           help="Optionally give a comma-separated list of particle widths for which values will be stored in the map file")
        dress.add_argument("-S", "--slha", dest="SLHA", default="MASS",
                           help="read parameters from a comma-seperated list of blocks in an SLHA file")
        dress.add_argument("-M", "--mass", dest="MASS",
                           help="Optionally give a comma-separated list of particle masses for which values will be stored in the map file")
        dress.add_argument("--BW", "--binwidth", dest="BINWIDTH",
                           help="optional binning of SLHA paramters")
        dress.add_argument("--BO", "--binoffset", dest="BINOFFSET",
                           help="optional bin offset for SLHA parameters")

    if "select" in active_groups:
        select = parser.add_argument_group("Options to exclude/include subsets of data")
        select.add_argument("--xr", "--nometratio",
                            action="store_true", dest="EXCLUDEMETRAT", default=False,
                            help="Exclude plots where exclusion would be based on a ratio to the SM dileptons"
                                 "Use this when you have ehnanced Z production in your model.")
        select.add_argument("--xhg", "--nohiggsgamma",
                            action="store_true", dest="EXCLUDEHGG", default=False,
                            help="Exclude plots where Higgs to photons signal is background-subtracted by fitting continuum."
                                 "Do this when you have large non-Higgs diphoton production from your model.")
        select.add_argument("--whw", "--withhiggsww",
                            action="store_true", dest="USEHWW", default=False,
                            help="Include plots where Higgs to WW signal is background-subtracted using data."
                                 "Only try this when you have large Higgs WW from your model and not much top or other source of WW.")
        select.add_argument("--wbv", "--withbvetos",
                            action="store_true", dest="USEBV", default=False,
                            help="Include plots where a b-jet veto was applied in the measurement but not in the fiducial definition."
                                 "Only try this when you have large W+jets enhancements and no extra top or other source of W+b.")
        select.add_argument("--awz", "--atlas-wz",
                            action="store_true", dest="USEAWZ", default=False,
                            help="Include the ATLAS WZ analysis with dodgy SM assumptions."
                                 "Might be useful for enhanced WZ cross sections but be careful.")
        select.add_argument("-s", "--use-searches",
                            action="store_true", dest="USESEARCHES", default=False,
                            help="Use reco-level search analyses in the sensitivity evaluation (beta).")
        select.add_argument("--wn", "--weight-name", dest="WEIGHTNAME", default="",
                            help="for weighted events/histos, select the name of the weight to use.")
        select.add_argument("--th", "--theory", action="store_true", dest="THY", default=False,
                            help="Use SM theory as the background model, where available.")
        select.add_argument("--to", "--theoryonly", action="store_true", dest="THONLY", default=False,
                            help="Only use those data where the SM theory prediction is available.")
        select.add_argument("--ana-match", action="append", dest="ANAPATTERNS", default=[],
                            help="only run on analyses whose name matches any of these regexes")
        select.add_argument("--ana-unmatch", action="append", dest="ANAUNPATTERNS", default=[],
                            help="exclude analyses whose name matches any of these regexes")
        select.add_argument("--split-pools", action="append", dest="POOLPATTERNS", default=[],
                            help="write out histograms from analyses in given pools separately")
        select.add_argument("--ana-split", action="append", dest="ANASPLIT", default=[],
                            help="write out histograms from given analyses separately")
        select.add_argument("-b", "--beams", action="append", dest="BEAMS", default=[],
                            help="in grid mode, only run on these beams")
        select.add_argument("-f", "--findPoint", action="append", dest="FINDPARAMS", default=[],
                            help="identify points consistent with these parameters and make histograms for them")
        select.add_argument("--el", "--expected_limits", action="store_true", dest="EXPECTED", default=False,
                            help="Ignore the data, and calculate the expected limits where SM theory is available.")

    if "stats" in active_groups:
        stats = parser.add_argument_group(
            'Options to Manipulate the constructed test statistic. They dont apply if correlations are switched off')
        stats.add_argument("-u", "--uncorrelate_errors", action="store_true", dest="UNCORR", default=False,
                           help="Master switch for turning off treatment of correlations.")
        stats.add_argument("--xtc", "--notheorycorr", action="store_true", dest="XTHCORR", default=False,
                           help="Assume SM theory uncertainties are uncorrelated")
        stats.add_argument("--mnp", "--minimize_np", action="store_true", dest="MIN_NP", default=False,
                           help="If using correlations, perform nuisance parameter minimization (slow)")
        stats.add_argument("--min_syst", dest="MIN_SYST", default=contur.config.min_syst,
                           help="If using correlations, correlated systematic errors with a maximum fractional contribution below this will be ignored (saves time!)")
        stats.add_argument("--error_precision", dest="ERR_PREC", default=contur.config.err_prec,
                           help="precision cut off in nuisance parameters when minimizing LL")
        stats.add_argument("--ll_precision", dest="LL_PREC", default=contur.config.ll_prec,
                           help="precision cut off in LL when minimizing it")
        stats.add_argument("--n_iter", dest="N_ITER", default=contur.config.n_iter,
                           help="minimize cuts off after n_iter*n_variables iterations")
        stats.add_argument("--min_num_sys", dest="MNS", default=2,
                           help="minimum number of systematic nuisance parameters for them to be treated as correlated")

    if "tools" in active_groups:
        options = parser.add_argument_group("Control options")

        parser.add_argument('scan_dirs', nargs='*', metavar='scan_dirs',
                            help='scan directories to process.')

        options.add_argument("--merge", action="store_true", dest="MERGE_GRIDS",
                             default=False, help="merge two or more grids using symbolic links. Excludes other options")

        options.add_argument("--rm", "--remove-merged", action="store_true", dest="RM_MERGED",
                             default=False, help="if unmerged yodas exist, unzip them, and remove merged ones")

        options.add_argument("-x", action="append", dest="ANAPATTERNS", default=[],
                             help="create a new grid containing output of only these analyses")

        options.add_argument("--nc", "--no-clean", action="store_true", dest="DO_NOT_CLEAN",
                             default=False, help="do not remove unnecessary files.")

        options.add_argument("--archive", action="store_true", dest="COMPRESS_GRID",
                             default=False, help="remove intermediate and unncessary files, and compress others.")

        options.add_argument("-c", "--check", action="store_true", dest="CHECK_GRID",
                             default=False, help="check whether all grid points have valid yodas")

        options.add_argument("--ca", "--check-all", action="store_true", dest="CHECK_ALL",
                             default=False, help="include grid points without logfiles when checking for yodas")

        options.add_argument("-S", "--submit", action="store_true", dest="RESUB",
                             default=False, help="(re)submit any jobs which are found to have failed.")

        options.add_argument("-f", "--findPoint", action="append", dest="FINDPARAMS", default=[],
                             help="identify points consistent with these parameters")

        options.add_argument("--detail", action="store_true", dest="PARAM_DETAIL", default=False,
                             help="output detailed information for certain parameter point")

        options.add_argument("--plot", action="store_true", dest="PLOT", default=False,
                             help="make histograms for specified parameters (much slower!)")

    if "batch" in active_groups:
        # Optional arguments
        parser.add_argument("-o", "--out_dir", dest="OUTPUTDIR", type=str,
                            metavar="output_dir", default="myscan00",
                            help="Specify the output directory name.")
        parser.add_argument('-p', '--param_file', dest='param_file', type=str,
                            default=contur.config.param_steering_file, metavar='param_file.dat',
                            help='File specifying parameter space.')
        parser.add_argument('-t', '--template', dest='template_file',
                            default=contur.config.mceg_template, metavar='template_file',
                            help='Template Herwig .in file.')
        parser.add_argument("-r", "--runinfo", dest="run_info", type=str,
                            default='RunInfo', metavar='run_info',
                            help=("Directory with required run information. Set to 'none' to not use one."))
        parser.add_argument("-n", "--numevents", dest="num_events",
                            default=contur.config.default_nev, metavar='num_events', type=int,
                            help="Number of events to generate.")
        parser.add_argument('--seed', dest='seed', metavar='seed', default=101,
                            type=int, help="Seed for random number generator.")
        parser.add_argument("-Q", "--queue", dest="queue", metavar="queue", default="",
                            type=str, help="batch queue.")
        parser.add_argument('-s', '--scan_only', '--scan-only', dest='scan_only', default=False,
                            action='store_true', help='Only perform scan and do not submit batch job.')
        parser.add_argument('-b', '--beams', dest="beams", default="all",
                            type=str, help="beam.")
        parser.add_argument('-P', '--pipe_hepmc', '--pipe-hepmc', dest="pipe_hepmc", default=False,
                            action='store_true', help="Rivet reading from pipe.")
        parser.add_argument('-w', '--wallTime', '--walltime', type=str, default=None,
                            help="Set maximum wall time for jobs (HH:MM).")
        parser.add_argument('--memory', type=str, default=None,
                            help="Set maximum memory consumption for jobs (e.g. 2G).")
        parser.add_argument('-B', '--batch', dest="batch_system", default='qsub',
                            type=str, metavar='batch_system',
                            help="Specify which batch system is using, support: qsub, condor or slurm")
        parser.add_argument("-m", "--mceg", dest="mceg", metavar="mceg", default=contur.config.mceg,
                            type=str, help="MC event generator.")
        parser.add_argument('-V', '--variablePrecision', action='store_true',
                            help='Use this flag to make number of events for each point variable')

        parser.add_argument("-g", "--analyse_grid", dest="analyse_grid", default=None,
                            help="run analysis and make map files from an existing grid.")
        parser.add_argument("-N", "--num_points", dest="num_points", default=50,
                            help="break an analysis run down into jobs/maps with N parameter points in each")
        parser.add_argument("-a", "--analysis_flags", dest="analysis_flags", default="",
                            help="flags to pass to the contur analysis step (separate with commas)")
        parser.add_argument("--setup", dest="setup_script", default=None,
                            help="specify a setup script to be sourced at start of analysis batch job.")
        parser.add_argument("-db", "--initDB", action="store_true", dest="INIT_DB", default=False,
                             help="init responsive db for grid mode")

    return parser


def valid_arguments(args):
    """
    Check that command line arguments are valid; return True or False.
    This function is also responsible for formatting some arguments e.g.
    converting the RunInfo path to an absolute path and checking it contains .ana files.
    valid_args = True

    Currently only works for *contur-batch*

    """
    valid_args = True
    beams = []
    known_beams = contur.data.getBeams()
    if args['beams'] == "all":
        beams = known_beams
    else:
        try_beams = args['beams'].split(",")
        for beam in try_beams:
            if beam in known_beams:
                beams.append(beam)
            else:
                contur.config.contur_log.error("Beam '%s' is not known. Possible beams are:" % beam)
                for beam in known_beams:
                    contur.config.contur_log.error(beam)
                valid_args = False

    if args['wallTime'] is not None:
        timespans = args['wallTime'].split(":")
        if len(timespans) != 2:
            contur.config.contur_log.error("Have to give max wall time in the format <hh:mm>!")
            valid_args = False
        else:
            try:
                for span in timespans:
                    span = int(span)
                    if span >= 60:
                        contur.config.contur_log.error(
                            "Have to give time spans of less than 60 [units]!")
                        valid_args = False
            except ValueError:
                contur.config.contur_log.error("Have to give time spans that can be converted to integers!")
                valid_args = False

    if args['memory'] is not None:
        number, unit = args['memory'][0:-1], args['memory'][-1]
        valid_units = ["M", "G"]
        if unit not in valid_units:
            contur.config.contur_log.error("'%s' is not a valid unit for the memory. (%s are valid units.)" % (
                unit, valid_units))
            valid_args = False
        if not number.isdigit():
            contur.config.contur_log.error("'%s' is not a valid number for the memory." % number)
            valid_args = False

    if args['analyse_grid']:
        contur.config.contur_log.info("Analysing existing grid: {}".format(args['analyse_grid']))
        if args['num_points']:
            try:
                n_points = int(args['num_points'])
                contur.config.contur_log.info(
                    "Splitting into {} parameter points per map file.".format(args['num_points']))
            except ValueError:
                contur.config.contur_log.error(
                    "Number of points {} cannot be converted to integer!".format(args['num_points']))
                valid_args = False

        return valid_args, beams

    if not os.path.exists(args['param_file']):
        contur.config.contur_log.error("Param file '%s' does not exist!" % args['param_file'])
        valid_args = False

    if not os.path.exists(args['template_file']):
        contur.config.contur_log.error("Template file '%s' does not exist!" % args['template_file'])
        valid_args = False

    if args['run_info'].lower() == 'none':
        args['run_info'] = None
    else:
        args['run_info'] = os.path.abspath(args['run_info'])
        if not os.path.isdir(args['run_info']):
            contur.config.contur_log.error("No such run information directory '{}'!".format(args['run_info']))
            valid_args = False

        else:
            for beam in beams:
                afile = beam + ".ana"
                if not os.path.exists(os.path.join(args['run_info'], afile)):
                    gpfrom = contur.config.path("data/share", afile)
                    gpto = os.path.join(args['run_info'], afile)
                    contur.config.contur_log.info("Copying {} to {}".format(gpfrom, gpto))
                    copyfile(gpfrom, gpto)

    try:
        int(args['num_events'])
    except ValueError:
        contur.config.contur_log.error("Number of events '%s' cannot be converted to integer!"
                                       % args['num_events'])
        valid_args = False

    try:
        args['seed'] = int(args['seed'])
    except ValueError:
        contur.config.contur_log.error("Seed '%s' cannot be converted to integer!" % args['seed'])
        valid_args = False

    if not (args['mceg'] == "herwig" or args['mceg'] == "madgraph" or args['mceg'] == "pbzpwp"):
        contur.config.contur_log.error("Unrecognised event generator: {}".format(args['mceg']))
        valid_args = False
    else:
        contur.config.mceg = args['mceg']
        contur.config.mceg_template = os.path.basename(args['template_file'])

    return valid_args, beams


def setup_common(args):
    """
    setup up the configuration parameters for the common arguments/flags
    if printVersion is set, do this and exit
    """
    
    if args['printVersion']:
        contur.util.write_banner()
        sys.exit(0)

    contur.config.contur_log.setLevel(logging.INFO)
    if args['QUIET']:
        contur.config.contur_log.setLevel(logging.WARNING)
    else:
        contur.util.write_banner()
    if args['DEBUG']:
        contur.config.contur_log.setLevel(logging.DEBUG)
        
    contur.config.output_dir = args['OUTPUTDIR']


        

def setup_batch(args):
    """
    setup up the configuration parameters for the batch arguments/flags
    """

    contur.config.param_steering_file = args['param_file']

    contur.config.using_condor = (args['batch_system'] == 'condor')
    contur.config.using_slurm = (args['batch_system'] == 'slurm')
    contur.config.using_qsub = not (
            contur.config.using_condor or contur.config.using_slurm)


def setup_stats(args, message):
    """ 
    setup the parameters for the stats argument group
    """

    if not args['UNCORR']:
        contur.config.buildCorr = True
        message += "Building all available data correlations, combining bins where possible \n"
        if not contur.config.min_syst == float(args['MIN_SYST']):
            contur.config.min_syst = float(args['MIN_SYST'])
            message += "Systematic materiality cutoff changed to {} \n".format(
                contur.config.min_syst)

        # are we minimising nuisance parameters?
        if args['MIN_NP']:
            message += "Attempting marginalisation over nuisance parameters \n"
            contur.config.min_np = True

            if not contur.config.ll_prec == float(args['LL_PREC']):
                contur.config.ll_prec = float(args['LL_PREC'])
                message += "LL precision criterion changed to  {} \n".format(
                    contur.config.ll_prec)

            if not contur.config.n_iter == int(args['N_ITER']):
                contur.config.n_iter = int(args['N_ITER'])
                message += "max number of iterations changed to  {} \n".format(
                    contur.config.n_iter)

            if not contur.config.err_prec == float(args['ERR_PREC']):
                contur.config.err_prec = float(args['ERR_PREC'])
                message += "Precision cut off in nuisance parameters when minimizing LL changed to {} \n".format(
                    contur.config.err_prec)

            if not args['MNS'] == int(args['MNS']):
                contur.config.min_num_sys = int(args['MNS'])
                message += "Minimum number of systematic uncertainties contributions for correlations changed to {} \n".format(
                    contur.config.min_num_sys)

    else:
        contur.config.buildCorr = False
        message += "No correlations being built, using single bins in tests \n"

    return message
