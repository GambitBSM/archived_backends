import rivet

import sys
import os
import pickle
import logging
import yoda

from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter

import contur
from contur.run.arg_utils import setup_stats, setup_common

def main(args):

    if (type(args) is not dict):
        args = vars(args)
        
    contur.config.setup_logger(filename=args['LOG'])
    print("Writing log to {}".format(contur.config.logfile_name))

    # set up / respond to the common argument flags.
    setup_common(args)
    
    modeMessage = "Performing SM test \n"
    modeMessage += "Contur is running in {} \n".format(os.getcwd())

    modeMessage = setup_stats(args,modeMessage)

    
    
    if args['ANAPATTERNS']:
        contur.config.onlyAnalyses = args['ANAPATTERNS']
        modeMessage += "Only using analysis objects whose path includes %s. \n" % args['ANAPATTERNS']

    if args['ANAUNPATTERNS']:
        contur.config.vetoAnalyses = args['ANAUNPATTERNS']
        modeMessage += "Excluding analyses names: %s. \n" % args['ANAUNPATTERNS']
    
    if args['XTHCORR']:
        contur.config.useTheoryCorr = False
        if not contur.config.useTheory:
            contur.config.contur_log.critical(
                "Option clash, requested uncorrelated theory uncertainty but not using theory")
            sys.exit(1)

        modeMessage += "Theory uncertainties assumed uncorrelated. \n"

    contur.config.contur_log.info(modeMessage)

    contur.config.useTheory=True
    contur.config.noStack=True

    plotdirs = [args["OUTPUTDIR"]]
    contur.config.plot_dir = args["OUTPUTDIR"]
    
    aopaths = []
    aolist= []
    pools = contur.data.getPools()
    for ana in sorted(pools, key=pools.get):
        th_desc = contur.data.getTheoryDescription(ana)
        if th_desc:
            for prediction in th_desc:
                aos = yoda.read(contur.config.path("data","Theory",prediction[2]))
                aopaths.extend(aos.keys())
                aolist.extend(aos.values())

    # load the reference data. in sm mode we never want to try read the background ts.
    tmp_mnp = contur.config.min_np
    contur.config.min_np = False
    #init_ref(aopaths)
    contur.config.min_np = tmp_mnp
    
    for thy in aolist:

        # remove the /THY prefix. 
        thy.setPath(thy.path()[4:])

        if contur.data.validHisto(thy.path()):

            # now load the REF and SM THY info for this analysis
            contur.factories.yoda_factories.load_bg_data(thy.path())
        
            hist = contur.factories.HistFactory(thy, None, None)
            if hist.pool is None:
                continue

            # estimate the stat error on the expected signal.
            # TODO: signal errors are symmetrised here. Does that make any difference? (should not)
            yErrs = hist.signal.yErrs()
            serrs = []
            for epair in yErrs:
                # these are the MC stat errors
                serrs.append((abs(epair[0]) + abs(epair[1]))*0.5)

            bin_widths = []
            try:
                for xerr in hist._background.xErrs():
                    bin_widths.append(xerr[0])

                    sm_likelihood = contur.factories.Likelihood(bw=bin_widths,
                                                                nobs=hist._ref.yVals(),
                                                                cov=hist._cov,
                                                                uncov=hist._uncov,
                                                                bg=hist._background.yVals(),
                                                                theorycov=hist._thCov, theoryuncov=hist._thUncov,
                                                                nuisErrs=hist._nuisErrs, thErrs=hist._thErrs,
                                                                ratio=hist._isRatio,
                                                                profile=hist._isProfile,
                                                                useTheory=True,
                                                                lumi=hist._lumi,
                                                                tags=rivet.stripOptions(hist.signal.path()))
            except AttributeError as ate:
                contur.config.contur_log.debug("Skipping: {}".format(thy.path()))
                continue

            hist.CLs = sm_likelihood.CLs
            hist.likelihood = sm_likelihood

            del hist.sigplot
            plotparser = rivet.mkStdPlotParser(plotdirs, )
            # write the dat file for plotting
            contur.util.write_histo_dat("", plotparser, True, hist)
            # write the test result file for reading
            contur.util.write_sm_test(plotdirs[0],hist)
        
def doc_argparser():
    """ wrap the arg parser for the documentation pages """    
    from contur.run.arg_utils import get_argparser    
    return get_argparser('smtest')
