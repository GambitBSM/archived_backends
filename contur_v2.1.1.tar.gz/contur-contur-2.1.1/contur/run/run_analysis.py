"""
Main module for running contur on a single yoda file or a parameter grid of yodafiles 
"""

import rivet

import sys
import os
import pickle
import logging
import contur.data

from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter

import contur
from contur.run.arg_utils import setup_stats, setup_common


def process_grid(args, pool=None, mergedDirs=[]):
    """
    process the grid, creating a depot and calling analyse_grid for each beam.

    """

    if args['INIT_DB']:
        contur.config.results_dbfile = contur.config.path('data', 'DB', 'responsive_storage.db')

    if pool is not None:
        contur.config.contur_log.info(
            "Processing grid for pool {}, analysis {}".format(pool, contur.config.onlyAnalyses))

    depots = {}
    # look for beams subdirectories in the chosen grid and analyse each of them
    known_beams = contur.data.getBeams(pool)
    for beam in known_beams:
        beam_dir = os.path.join(contur.config.grid, beam)

        if (beam in args['BEAMS'] or len(args['BEAMS']) == 0) and os.path.exists(beam_dir):

            # merge/rename all the yoda files for each beam and parameter point
            if not beam in mergedDirs:

                contur.scan.grid_loop(scan_path=beam_dir, unmerge=args['new'])
                mergedDirs.append(beam)

            contur_depot = contur.factories.Depot(noStack=args['NOSTACK'])
            analyse_grid(os.path.abspath(beam_dir), contur_depot, args)
            # save some memory
            contur_depot.resort_points()
            depots[beam_dir] = contur_depot

        # RESET the refload flag for the next beam
        contur.config.refLoaded = False

    if len(depots) > 0:
        # merge maps for each beam
        contur.config.contur_log.info("Merging maps")
        target = None
        for beam, depot in depots.items():
            if len(depot.inbox)>0:
                if not target:
                    target = depot
                else:
                    target.merge(depot)
            else:
                contur.config.contur_log.warn("No {} data".format(beam))

        if target:
            target.resort_points()
            target.write(contur.config.output_dir)
            write_grid_output("Output the most sensitive histogram for grid mode \n", target)
            # populate the local database for this grid
            if contur.config.results_dbfile:
                contur.data.write_grid_data(args['RUNNAME'],target)

    elif len(args['BEAMS']) == 0:

        # look for yoda files in the top level directory and analyse them.
        ctdp = contur.factories.Depot(noStack=args['NOSTACK'])
        analyse_grid(os.path.abspath(contur.config.grid), ctdp, args)

        ctdp.write(os.path.join(contur.config.output_dir))

    else:
        contur.config.contur_log.info("No compatible yoda files found.")

def write_grid_output(message, conturDepot):
    """
    Write a brief text summary of a run, and also write info about the
    most sensitive histograms in each pool
    """
    contur.util.mkoutdir(contur.config.output_dir)
    sumfn = open(os.path.join(contur.config.output_dir,contur.config.grid_summary_file),'w')

    contur.config.contur_log.info("Writing summary for grid mode to : {}".format(sumfn.name))
                     
    sumfn.write(message)
    if conturDepot.inbox is None:
        sumfn.write("\nParameter point is empty! \n")
    else:
        sumfn.write("Number of parameter points: " + str(len(conturDepot.inbox))+"\n")
        # sumfn.write("type: " +str(type(conturDepot.inbox)))

    for param_yoda_point in conturDepot.inbox:
        sumfn.write("\n**************************************\n")

        if param_yoda_point.yoda_factory._full_likelihood.CLs is not None:
            result = " \nCombined exclusion for these plots is %.2f %% \n" % (
                    param_yoda_point.yoda_factory._full_likelihood.CLs * 100.0)
        else:
            result = "Could not evaluate exclusion for these data. Try turning off theory correlations?"

        sumfn.write("\n" + result + "\n")
        # write parameter point in the Summary file
        for param, val in param_yoda_point.param_point.items():
            sumfn.write(param + " = " + str(val) + "\n")

        sumfn.write("\npools")
        for x in param_yoda_point.yoda_factory._sorted_likelihood_blocks:
            sumfn.write("\n" + x.pools)
            sumfn.write("\n" + str(x.CLs))
            sumfn.write("\n" + rivet.stripOptions(x.tags))

    sumfn.close()


def analyse_grid(scan_paths, conturDepot, args):
    """
    perform the analysis on a grid (called by process_grid) and store results in the depot

    """

    yoda_counter = 0
    yodapaths = []
    parampaths = []

    for scan_path in scan_paths.split(","):
        for root, dirs, files in sorted(os.walk(scan_path)):

            valid_yoda_file = False
            for file_name in files:
                valid_yoda_file = ((file_name.endswith('.yoda')
                                    or file_name.endswith('.yoda.gz'))
                                   and
                                   'LHC' not in file_name and
                                   'run' in file_name)
                if valid_yoda_file: 
                    yoda_counter += 1
                    yoda_file_path = os.path.join(root, file_name)
                    break

            if not valid_yoda_file:
                continue

            param_file_path = os.path.join(root, contur.config.paramfile)
            yodapaths.append(yoda_file_path)
            parampaths.append(param_file_path)
            contur.config.contur_log.debug(
                'Reading parameters from {}'.format(param_file_path))
            params = contur.util.read_param_point(param_file_path)
            contur.config.contur_log.info('Found valid yoda file ' +
                                  yoda_file_path.strip('./'))
            sample_str = 'Sampled at:'
            tmp_params = {}
            for param, val in params.items():
                sample_str += ('\n'+param + ': ' + str(val))

                if args['SLHA'] and param=="slha_file":
                    block_list = args['SLHA'].split(",")
                # read parameters from blocks in an SLHA file
                    block_dict = contur.util.read_slha_file(root, val, block_list)
                    for block in block_list:
                        tmp_params.update(block_dict[block])

            params.update(tmp_params)
            contur.config.contur_log.info(sample_str)

            # If requested, grab some values from the log file and add them as extra parameters.
            if args['ME']:
                params.update(contur.util.read_herwig_out_file(
                        root, files, args['ME'].split(",")))
            bf_list = None
            width_list = None
            mass_list = None
            if args['BF'] is not None:
                bf_list = args['BF'].split(",")
            if args['WIDTH'] is not None:
                width_list = args['WIDTH'].split(",")
            if args['MASS'] is not None:
                mass_list = args['MASS'].split(",")

            if args['BF'] or args['WIDTH'] or args['MASS']:
                params.update(contur.util.read_herwig_log_file(
                        root, files, bf_list, width_list, mass_list))


        # Perform analysis
            conturDepot.add_point(
                param_dict=params, yodafile=yoda_file_path)


    contur.config.contur_log.info("Found %i yoda files" % yoda_counter)
    conturDepot.build_axes()


def main(args):
    """
    Main programme to run contur analysis on a grid of yoda files, a single yoda, or a yoda stream.
    """

    if (type(args) is not dict):
        args = vars(args)
    if 'YODASTREAM' not in args:
        args['YODASTREAM'] = None
    
    contur.config.grid = args['GRID']
    
    modeMessage = "Run Information \n"

    modeMessage += "Contur is running in {} \n".format(os.getcwd())
    if contur.config.grid:
        modeMessage += "on files in {} \n".format(contur.config.grid)
        contur.config.gridMode = True
        contur.config.mapfile = args['MAPFILE']
        contur.config.silenceWriter = True
    elif args['YODASTREAM'] is None:
        modeMessage += "on analysis objects in {} \n".format(args['yoda_files'])
        contur.config.gridMode = False
    else:
        modeMessage += "on analysis objects in YODASTREAM StringIO \n"
        contur.config.gridMode = False
        if not args.get('UNSILENCE_WRITER_FOR_STREAMS', False):
            contur.config.silenceWriter=True
        
    contur.config.setup_logger(filename=args['LOG'])
    print("Writing log to {}".format(contur.config.logfile_name))
    
    # set up / respond to the common argument flags.
    setup_common(args)

    # set up the plot output directory
    contur.config.plot_dir = os.path.join(contur.config.output_dir,"plots")

    if args['EXCLUDEHGG']:
        contur.config.excludeHgg = True
        modeMessage += "Excluding Higgs to photons measurements \n"

    if args['USESEARCHES']:
        contur.config.excludeSearches = False
        modeMessage += "Using search analyses \n"

    if args['USEHWW']:
        contur.config.excludeHWW = False
        modeMessage += "Including Higgs to WW measurements if available \n"
    else:
        contur.config.excludeHWW = True
        modeMessage += "Excluding Higgs to WW measurements \n"

    if args['USEBV']:
        contur.config.excludeBV = False
        modeMessage += "Including secret b-veto measurements if available \n"
    else:
        contur.config.excludeBV = True
        modeMessage += "Excluding secret b-veto measurements \n"

    if args['USEAWZ']:
        contur.config.excludeAWZ = False
        modeMessage += "Including ATLAS WZ SM measurement \n"
    else:
        contur.config.excludeAWZ = True
        modeMessage += "Excluding ATLAS WZ SM measurement \n"

    if args['EXCLUDEMETRAT']:
        contur.config.excludeMETRatio = True
        modeMessage += "Excluding MET ratio measurements \n"


    if (not args['yoda_files'] and not contur.config.gridMode and (args['YODASTREAM'] is None)):
        contur.config.contur_log.critical("Error: You need to specify some YODA files to be "
                              "analysed!\n")
        sys.exit(1)

    if (not args.get('UNSILENCE_WRITER_FOR_STREAMS', False)) and args.get('OUTPUTDIR') is None:
        contur.config.contur_log.critical("Error: If you wish to output .dat files running on a "
        "yoda stream, you must specify an OUTPUTDIR")
        sys.exit(1)

    if args['WEIGHTNAME'] is not None:
        contur.config.weight = args['WEIGHTNAME']

    contur.util.write_banner()

    # Set the global args used in config.py
    if args['PARAM_FILE']:
        contur.config.paramfile = args['PARAM_FILE']

    modeMessage = setup_stats(args, modeMessage)
        
    if args['THY'] or args['EXPECTED']:
        contur.config.useTheory = True
        modeMessage += "Using theory calculations for background model where available. \n"
    else:
        contur.config.useTheory = False
        modeMessage += "Building default background model from data, ignoring (optional) SM theory predictions \n"

    if args['THONLY']:
        contur.config.theoryOnly = True
        modeMessage += "Only use measurements where theory calculations for background model are available. \n"
    else:
        contur.config.theoryOnly = False

    if args['EXPECTED']:
        contur.config.expectedLimit = True
        contur.config.theoryOnly = True
        modeMessage += "Only calculating expected limits -- ignoring the actual data. \n"

    if args['XTHCORR']:
        contur.config.useTheoryCorr = False
        if not contur.config.useTheory:
            contur.config.contur_log.critical(
                "Option clash, requested uncorrelated theory uncertainty but not using theory")
            sys.exit(1)

        modeMessage += "Theory uncertainties assumed uncorrelated. \n"
    elif contur.config.useTheory:
        contur.config.useTheoryCorr = True
        modeMessage += "Theory uncertainty correlations used. \n"

    if args['ANAPATTERNS']:
        contur.config.onlyAnalyses = args['ANAPATTERNS']
        modeMessage += "Only using analysis objects whose path includes %s. \n" % args['ANAPATTERNS']
    if args['ANASPLIT']:
        contur.config.splitAnalysis = True
        modeMessage += "Splitting these analyses into seperate histograms %s. \n" % args['ANASPLIT']
    if args['ANAUNPATTERNS']:
        contur.config.vetoAnalyses = args['ANAUNPATTERNS']
        modeMessage += "Excluding analyses names: %s. \n" % args['ANAUNPATTERNS']
    if args['POOLPATTERNS']:
        modeMessage += "Splitting analyses of pools %s. \n" % args['POOLPATTERNS']

    if args['BINWIDTH']:
        contur.config.binwidth = float(args['BINWIDTH'])
    if args['BINOFFSET']:
        contur.config.binoffset = float(args['BINOFFSET'])
    if args['MODEL']:
        modeMessage += '\n Model: ' + args['MODEL']
        contur.config.contur_log.info('\n Model: ' + args['MODEL'])

    contur.config.contur_log.info(modeMessage)

    ctdp = contur.factories.Depot(noStack=args['NOSTACK'])

    # rather than porting arguments though class instance initialisations, instead set these as variables in the global config.py
    # all these are imported on import contur so set them here and pick them up when needed later

    if contur.config.gridMode:
        # grid mode
        # --------------------------------------------------------------------------------------------------
        mergedDirs = []
        if args['POOLPATTERNS']:
            # In this case we are running on specified pools and breaking them down into separate analyses
            anaDir = contur.config.output_dir
            for pool in args['POOLPATTERNS']:
                anas = contur.data.getAnalyses(pool)
                for a in anas:
                    if a in contur.config.vetoAnalyses:
                        continue
                    contur.config.onlyAnalyses = args['ANAPATTERNS'] + \
                        [a]  # add analysis to must-match anas
                    # setup a different directory for each ana
                    contur.config.output_dir = os.path.join(anaDir, pool, a)
                    process_grid(args, pool, mergedDirs)
            contur.config.output_dir = anaDir  # reset ANALYSIDIR to original value
        elif contur.config.splitAnalysis:
            # In this case we are running on specified analyses and breaking them down into histos/subpools.
            anaDir = contur.config.output_dir
            # One analysis at a time
            for ana in args['ANASPLIT']:
                contur.config.contur_log.info(
                    'Running grid on {} and splitting it into pools'.format(ana))
                # setup a different directory for each ana
                contur.config.output_dir = os.path.join(anaDir, ana)
                contur.config.onlyAnalyses = args['ANAPATTERNS'] + [ana]
                # for subpool/hist etc
                process_grid(args, None, mergedDirs)

            contur.config.output_dir = anaDir  # reset ANALYSIDIR to original value

        else:
            # In this case we are running on everything
            process_grid(args)

        contur.util.write_summary_file(modeMessage, ctdp)

    elif (args['YODASTREAM'] is None):
        # single mode
        # --------------------------------------------------------------------------------------------------

        # find the specified parameter point.
        yodaFiles = contur.scan.find_param_point(
            args['yoda_files'], args['TAG'], args['FINDPARAMS'])

        for infile in yodaFiles:

            anaDir = contur.config.output_dir
            plotDir = contur.config.plot_dir
            contur.config.output_dir = os.path.join(
                os.path.dirname(infile), anaDir)
            contur.config.plot_dir = os.path.join(
                os.path.dirname(infile), plotDir)

            ctdp = contur.factories.Depot(noStack=args['NOSTACK'])

            # get info from paramfile if it is there
            param_file_path = os.path.join(
                os.path.dirname(infile), contur.config.paramfile)
            if os.path.exists(param_file_path):
                params = contur.util.read_param_point(param_file_path)
                modeMessage += '\nSampled at:'
                for param, val in params.items():
                    modeMessage += '\n' + param + ': ' + str(val)
            else:
                params = {}
                params["No parameters specified"] = 0.0
                modeMessage += "\nParameter values not known for this run."


            # If requested, grab some values from the log file and add them as extra parameters.
            root = "."

            tmp_params = {}
            for param, val in params.items():
                if args['SLHA'] and param=="slha_file":
                    block_list = args['SLHA'].split(",")
                    # read parameters from blocks in an SLHA file
                    block_dict = contur.util.read_slha_file(root, val, block_list)
                    for block in block_list:
                        tmp_params.update(block_dict[block])

            params.update(tmp_params)

            files = os.listdir(root)

            # If requested, grab some values from the log file and add them as extra parameters.
            if args['ME']:
                params.update(contur.util.read_herwig_out_file(
                    root, files, args['ME'].split(",")))
            bf_list = None
            width_list = None
            mass_list = None
            if args['BF'] is not None:
                bf_list = args['BF'].split(",")
            if args['WIDTH'] is not None:
                width_list = args['WIDTH'].split(",")
            if args['MASS'] is not None:
                mass_list = args['MASS'].split(",")

            if args['BF'] or args['WIDTH'] or args['MASS']:
                params.update(contur.util.read_herwig_log_file(
                    root, files, bf_list, width_list, mass_list))

            # read the yodafile, do the comparison
            ctdp.add_point(param_dict=params, yodafile=infile)

            contur.config.contur_log.info(modeMessage)
            contur.util.write_summary_file(modeMessage, ctdp)

            contur.config.output_dir = anaDir  # reset ANALYSIDIR to original value
            contur.config.plot_dir = plotDir  # reset ANALYSIDIR to original value

    else:
        # single mode, but run from YODA stream
        # --------------------------------------------------------------------------------------------------

        ctdp = contur.factories.Depot(noStack=args['NOSTACK'])

        
        params = {}
        params["No parameters specified"] = 0.0
        modeMessage += "\nParameter values not known for this run."


        # If requested, grab some values from the log file and add them as extra parameters.
        root = "."
        files = os.listdir(root)

        # If requested, grab some values from the log file and add them as extra parameters.
        if args['ME']:
            params.update(contur.util.read_herwig_out_file(
                root, files, args['ME'].split(",")))
        bf_list = None
        width_list = None
        mass_list = None
        if args['BF'] is not None:
            bf_list = args['BF'].split(",")
        if args['WIDTH'] is not None:
            width_list = args['WIDTH'].split(",")
        if args['MASS'] is not None:
            mass_list = args['MASS'].split(",")

        if args['BF'] or args['WIDTH'] or args['MASS']:
            params.update(contur.util.read_herwig_log_file(
                root, files, bf_list, width_list, mass_list))

        # read the yodafile, do the comparison
        ctdp.add_point(param_dict=params, yodafile=args['YODASTREAM'])

        contur.config.contur_log.info(modeMessage)

        return_dict = {}
        output_options = args.get('YODASTREAM_API_OUTPUT_OPTIONS', [])

        if "LLR" in output_options:
            if ((ctdp.inbox[0].yoda_factory._full_likelihood.ts_s_b is not None)
            and ctdp.inbox[0].yoda_factory._full_likelihood.ts_b is not None): 
                return_dict["LLR"] = (ctdp.inbox[0].yoda_factory._full_likelihood.ts_s_b 
                    - ctdp.inbox[0].yoda_factory._full_likelihood.ts_b)
            else:
                return_dict["LLR"] = 0.0
            
        if "CLs" in output_options:
            return_dict["CLs"] = ctdp.inbox[0].yoda_factory._full_likelihood.CLs

        if "Pool_LLR" in output_options:
            return_dict["Pool_LLR"] = {}
            for i in range(0, len(ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks)):
                if ((ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].ts_s_b is not None)
                and (ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].ts_b is not None)):
                    (return_dict["Pool_LLR"])[ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].pools] = (
                        ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].ts_s_b - 
                            ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].ts_b)
                else:
                    (return_dict["Pool_LLR"])[ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].pools] = 0.0

        if "Pool_CLs" in output_options:
            return_dict["Pool_CLs"] = {}
            for i in range(0, len(ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks)):
                (return_dict["Pool_CLs"])[ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].pools] = (
                    ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].CLs)

        if "Pool_tags" in output_options:
            return_dict["Pool_tags"] = {}
            for i in range(0, len(ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks)):
                (return_dict["Pool_tags"])[ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].pools] = (
                    ctdp.inbox[0].yoda_factory.sorted_likelihood_blocks[i].tags)

        return return_dict

def doc_argparser():
    """ wrap the arg parser for the documentation pages """    
    from contur.run.arg_utils import get_argparser    
    return get_argparser('analysis')
