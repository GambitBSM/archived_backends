"""
Perform various manipulations on an existing contur scan grid or grids, but NOT the actual contur statistical analysis.
"""

import logging
import os
import sys
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
import sqlite3 as db

import contur
from contur.scan.grid_tools import grid_loop, find_param_point


def main(args):
    contur.config.setup_logger(filename="contur_gridtool.log")
    print("Writing log to {}".format(contur.config.logfile_name))

    contur.config.contur_log.setLevel(logging.INFO)

    if len(args.scan_dirs) == 0:
        contur.config.contur_log.critical("No grid directory specified")
        sys.exit(1)

    Clean = True
    if args.DO_NOT_CLEAN:
        contur.config.contur_log.info("Not removing unnecessary files from grid")
        Clean = False

    if args.MERGE_GRIDS:
        print("Merging Grids")
        contur.scan.merge_main(sys.argv[2:])
        sys.exit(0)

    elif args.ANAPATTERNS:
        contur.config.contur_log.info("Extract histograms from {} into a new grid".format(args.ANAPATTERNS))
        if not len(args.scan_dirs) == 1:
            contur.config.contur_log.critical(
                "Requires exactly one directory. {} given. ({})".format(len(args.scan_dirs), args.scan_dirs))
            sys.exit(1)

        grid_loop(scan_path=args.scan_dirs[0], patterns=args.ANAPATTERNS, extract=True, clean=Clean)

    elif args.RM_MERGED:
        contur.config.contur_log.info("If unmerged yodas exists, unzipping them and removing merge yodas.")
        grid_loop(scan_path=args.scan_dirs[0], unmerge=True, clean=Clean)

    elif args.COMPRESS_GRID:
        contur.config.contur_log.info("Archiving this directory tree")
        grid_loop(scan_path=args.scan_dirs[0], archive=True)

    elif args.CHECK_GRID or args.CHECK_ALL:
        contur.config.contur_log.info("Checking directory tree")
        if args.CHECK_ALL:
            contur.config.contur_log.info("Also counting jobs without batch logs as failed")
        grid_loop(scan_path=args.scan_dirs[0], check=True, resub=args.RESUB, check_all=args.CHECK_ALL, queue=args.queue)


    elif args.FINDPARAMS:
        # find the specified parameter point.
        yoda_files = []
        dbfile = contur.config.path('data', 'DB', 'responsive_storage.db')
        conn = db.connect(dbfile)
        c = conn.cursor()
        model_point = c.execute(
            "select name from sqlite_master where type=\'table\' and name = \'model_point\'").fetchall()
        # there is no data in responsive db, find parameter by scanning the directory
        if len(model_point) == 0:
            if args.PARAM_DETAIL:
                contur.config.contur_log.warning(
                    "The database is empty, you should do a contur run before querying detailed information.")
            else:
                yoda_files = find_param_point(args.scan_dirs, contur.config.tag, args.FINDPARAMS)
        # database is not empty
        else:
            if args.PARAM_DETAIL:
                yoda_files = contur.data.show_param_detail_db(args.scan_dirs, args.FINDPARAMS)
            else:
                yoda_files = contur.data.find_param_point_db(args.scan_dirs, args.FINDPARAMS)

        if args.PLOT:
            contur.config.contur_log.info("*************************************************")
            contur.config.contur_log.info("Starting making histogram for matched yoda files")
            for yoda_file in yoda_files:
                os.system("gzip -d " + yoda_file)
                yoda_file_unziped = ".".join(yoda_file.split(".")[:-1])
                os.system("contur " + yoda_file_unziped)
                os.chdir(os.path.dirname(yoda_file_unziped))
                os.system("contur-mkhtml " + yoda_file_unziped)

    elif Clean:
        grid_loop(scan_path=args.scan_dirs[0], clean=Clean)

    if args.INIT_DB:
        contur.config.contur_log.info("generate db with model and parameter data initialised")
        contur.data.generate_model_and_parameter()

    sys.exit(0)


def doc_argparser():
    """ wrap the arg parser for the documentation pages """
    from contur.run.arg_utils import get_argparser
    return get_argparser('gridtools')
