. /herwig/bin/activate \
    && . /herwig/etc/bash_completion.d/yoda-completion \
    && . /herwig/etc/bash_completion.d/rivet-completion