# docker image rm $(docker images "dev_contur" --format "{{.ID}}")

docker-compose build