contur.run package
==================

Top level module for running contur. Submodules accessed directly from executable scripts in ``$CONTUR_ROOT/bin``.


Submodules
----------

contur.run.run\_analysis module
-------------------------------

.. automodule:: contur.run.run_analysis
   :members:
   :undoc-members:
   :show-inheritance:

contur.run.run\_batch\_submit module
------------------------------------

.. automodule:: contur.run.run_batch_submit
   :members:
   :undoc-members:
   :show-inheritance:

contur.run.run\_grid\_tools module
----------------------------------

.. automodule:: contur.run.run_grid_tools
   :members:
   :undoc-members:
   :show-inheritance:

contur.run.run\_plot module
----------------------------------

.. automodule:: contur.run.run_plot
   :members:
   :undoc-members:
   :show-inheritance:
      
Module contents
---------------

.. automodule:: contur.run
   :members:
   :undoc-members:
   :show-inheritance:
