#! /bin/bash
#$ -j y # Merge the error and output streams into a single file
#$ -o /unix/cedar/jmb/Work/TC/Scan1/Herwig/myscan03/13TeV/0007/contur_batch.log
source /unix/cedar/software/cos7/Herwig-repo_Rivet-repo/setupEnv.sh;
source /home/jmb/gitstuff/contur-dev/setupContur.sh ;
cd /unix/cedar/jmb/Work/TC/Scan1/Herwig/myscan03/13TeV/0007;
Herwig read LHC.in -I /unix/cedar/jmb/Work/TC/Scan1/Herwig/RunInfo -L /unix/cedar/jmb/Work/TC/Scan1/Herwig/RunInfo;
Herwig run LHC.run --seed=101 --tag=runpoint_0007 --numevents=30000;
