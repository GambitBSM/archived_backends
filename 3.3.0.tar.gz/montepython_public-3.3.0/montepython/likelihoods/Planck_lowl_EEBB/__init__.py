from montepython.likelihood_class import Likelihood_clik


class Planck_lowl_EEBB(Likelihood_clik):
    pass
