from montepython.likelihood_class import Likelihood_clik


class clik_wmap_lowl(Likelihood_clik):
    pass
