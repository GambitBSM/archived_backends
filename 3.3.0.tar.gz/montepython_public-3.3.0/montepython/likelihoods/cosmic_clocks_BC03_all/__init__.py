from montepython.likelihood_class import Likelihood_clocks


class cosmic_clocks_BC03_all(Likelihood_clocks):
    pass
