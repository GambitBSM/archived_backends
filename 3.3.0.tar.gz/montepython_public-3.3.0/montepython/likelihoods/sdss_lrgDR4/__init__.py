# likelihood for P(k) from SDSS LRG (DR4)
from montepython.likelihood_class import Likelihood_mpk


class sdss_lrgDR4(Likelihood_mpk):
    pass
