from montepython.likelihood_class import Likelihood_clocks


class cosmic_clocks_2016(Likelihood_clocks):
    pass
