from montepython.likelihood_class import Likelihood_clik


class Planck15_highl_lite(Likelihood_clik):
    pass
