from montepython.likelihood_class import Likelihood_clik


class Planck_highl_TTTEEE(Likelihood_clik):
    pass
