Problems to be addressed
========================


- Possibility to ask in input of the info module a sub-covariance matrix to be
  analysed, for a proper marginalised sub-covariance matrix.
- if a chain number is provided, files might be erased. Prevent that.
- beam not defined 613 likelihood_class.py
- part to read chains from cosmomc does not work
- We wanted to do sthg about parameter names too exotic, with ", ^, etc,
  replaced by a _ What was it already ?
- :code:`self.new_scales` to remove from :code:`analyze.py`
