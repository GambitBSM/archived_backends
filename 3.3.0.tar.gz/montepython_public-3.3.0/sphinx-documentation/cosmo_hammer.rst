Cosmo Hammer module
======================

.. automodule:: cosmo_hammer
    :members:
    :undoc-members:
    :show-inheritance:
