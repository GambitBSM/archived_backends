Sampler module
==============

.. automodule:: sampler
    :members:
    :undoc-members:
    :show-inheritance:
