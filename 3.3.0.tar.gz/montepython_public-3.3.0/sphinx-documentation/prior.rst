Prior module
============

.. automodule:: prior

.. autoclass:: Prior
    :members:
    :undoc-members:
    :show-inheritance:
    :member-order: bysource
