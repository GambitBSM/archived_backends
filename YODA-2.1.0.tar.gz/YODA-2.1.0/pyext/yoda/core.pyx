#################################################
#############       WARNING      ################
#################################################
# This file has been automatically generated.
# Any changes you make here will get overridden.
# Instead, make your changes in templates/*.dat
#################################################
# cython: embedsignature=True
# cython: c_string_type=str, c_string_encoding=utf8

## System / stdlib imports
from cython.operator cimport dereference as deref, preincrement as preinc
from cython.operator cimport address
from libcpp.string cimport string
from libcpp.vector cimport vector
from libcpp.pair cimport pair
from libcpp.map cimport map

## YODA mapping imports
cimport yoda.declarations as c
cimport yoda.util as cutil
import yoda.util as util

## Pure Python imports
from itertools import repeat
from operator import attrgetter
import sys

def version():
    "Return YODA library version as a string"
    return c.version()

def getLibPath():
    "Return the directory containing the YODA library"
    return c.getLibPath()

def getDataPath():
    "Return the directory containing the YODA data files"
    return c.getDataPath()

def getYodaDataPath():
    "Return the list of directories containing YODA data files"
    return c.getYodaDataPath()

include "include/AnalysisObject.pyx"
include "include/Binning.pyx"
include "include/Counter.pyx"
include "include/Dbn0D.pyx"
include "include/Errors.pyx"
include "include/Estimate.pyx"
include "include/Estimate0D.pyx"
include "include/Functions.pyx"
include "include/Point.pyx"
include "include/generated/Axis.pyx"
include "include/generated/Bin1D.pyx"
include "include/generated/Bin2D.pyx"
include "include/generated/Bin3D.pyx"
include "include/generated/BinnedEstimate1D.pyx"
include "include/generated/BinnedEstimate2D.pyx"
include "include/generated/BinnedEstimate3D.pyx"
include "include/generated/BinnedHisto1D.pyx"
include "include/generated/BinnedHisto2D.pyx"
include "include/generated/BinnedHisto3D.pyx"
include "include/generated/BinnedProfile1D.pyx"
include "include/generated/BinnedProfile2D.pyx"
include "include/generated/Dbn1D.pyx"
include "include/generated/Dbn2D.pyx"
include "include/generated/Dbn3D.pyx"
include "include/generated/IO.pyx"
include "include/generated/Point1D.pyx"
include "include/generated/Point2D.pyx"
include "include/generated/Point3D.pyx"
include "include/generated/Point4D.pyx"
include "include/generated/Scatter1D.pyx"
include "include/generated/Scatter2D.pyx"
include "include/generated/Scatter3D.pyx"
include "include/generated/Scatter4D.pyx"
