#include "YODA/Scatter.h"

#include <iostream>
using namespace std;
using namespace YODA;

int main() {
  return EXIT_SUCCESS;
}
