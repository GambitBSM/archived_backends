var searchData=
[
  ['linear_5for_5flogarithmic',['linear_or_logarithmic',['../primordial_8h.html#af97c57fb2cbf4f53e76a1c0ddfb04322',1,'primordial.h']]]
];
