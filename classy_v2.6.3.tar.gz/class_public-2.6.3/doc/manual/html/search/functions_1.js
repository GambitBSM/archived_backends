var searchData=
[
  ['class_5ffzero_5fridder',['class_fzero_ridder',['../input_8c.html#a3fce286212c955b92a4cfd3f76194e2e',1,'input.c']]]
];
