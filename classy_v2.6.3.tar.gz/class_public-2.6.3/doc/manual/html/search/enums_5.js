var searchData=
[
  ['radial_5ffunction_5ftype',['radial_function_type',['../transfer_8h.html#af3f4670b8918a9905edf8d0c2c5ce32b',1,'transfer.h']]],
  ['recombination_5falgorithm',['recombination_algorithm',['../thermodynamics_8h.html#a244f4d3fb288b63e3f02cc0a0c7961e3',1,'thermodynamics.h']]],
  ['reionization_5fparametrization',['reionization_parametrization',['../thermodynamics_8h.html#a355aa0469515c247f71668a5be5f4cc0',1,'thermodynamics.h']]],
  ['reionization_5fz_5for_5ftau',['reionization_z_or_tau',['../thermodynamics_8h.html#abfa56c8448beea105d10a6e89742e3a0',1,'thermodynamics.h']]]
];
