#if 0
	SLHA.h
		declarations of the external SLHA functions
		last modified 30 Nov 11 th
#endif

#include "SLHADefs.h"

	RealType SLHAGetDecay
	external SLHAGetDecay

	integer SLHANewDecay, SLHADecayTable
	external SLHANewDecay, SLHADecayTable

	integer SLHAExist, SLHAValid
	external SLHAExist, SLHAValid

