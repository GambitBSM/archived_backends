This backend is a simple python script that interpolates SUSY cross-sections, along with the data stored in the required format. 

For the original data, and further description, please see https://twiki.cern.ch/twiki/bin/view/LHCPhysics/SUSYCrossSections.
